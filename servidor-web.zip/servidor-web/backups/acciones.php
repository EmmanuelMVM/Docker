<?php
// CREAR BACKUP MANUAL
if (isset($_GET['crear_backup'])) {
    $output  = shell_exec("bash copiar_backup.sh 2>&1");
    $mensaje = "<p>✅ Copia de seguridad iniciada." . ($output ? " Salida: " . htmlspecialchars($output) : "") . "</p>";
}

// ELIMINAR TODOS LOS ARCHIVOS
if (isset($_GET['eliminar_todo'])) {
    $archivosEliminar = scandir($directorio);
    $eliminados = 0; $errores = 0;
    foreach ($archivosEliminar as $arch) {
        if ($arch === '.' || $arch === '..') continue;
        $ruta = $directorio . '/' . $arch;
        if (is_file($ruta)) {
            unlink($ruta) ? $eliminados++ : $errores++;
        }
    }
    $mensaje = "<p>Se eliminaron $eliminados archivo(s)." . ($errores ? " $errores no pudieron eliminarse." : "") . "</p>";
}

// VER SQL
if (isset($_GET['ver'])) {
    $archivo = $_GET['ver'];
    if (file_exists($directorio . '/' . $archivo) && pathinfo($archivo, PATHINFO_EXTENSION) === 'sql') {
        shell_exec("gedit " . escapeshellarg($directorio . '/' . $archivo) . " > /dev/null 2>&1 &");
    } else {
        $mensaje = "<p>Archivo no válido o no encontrado.</p>";
    }
}

// BLOQUEAR SQL -> GZ -> GPG
if (isset($_GET['bloquear'])) {
    $archivo = $_GET['bloquear'];
    if (file_exists($directorio . '/' . $archivo) && pathinfo($archivo, PATHINFO_EXTENSION) === 'sql') {
        $sqlFile = $directorio . '/' . $archivo;
        shell_exec("gzip -f " . escapeshellarg($sqlFile));
        $gzFile = $sqlFile . '.gz';
        shell_exec("gpg --batch --yes --passphrase 'asix' --symmetric --cipher-algo AES256 " . escapeshellarg($gzFile));
        unlink($gzFile);
        $mensaje = "<p>El archivo $archivo ha sido bloqueado correctamente.</p>";
    }
}

// DESBLOQUEAR GPG -> GZ -> SQL
if (isset($_GET['desbloquear'])) {
    $archivo = $_GET['desbloquear'];
    if (file_exists($directorio . '/' . $archivo) && pathinfo($archivo, PATHINFO_EXTENSION) === 'gpg') {
        $gpgFile = $directorio . '/' . $archivo;
        $base    = preg_replace('/\.gpg$/', '', $gpgFile);
        shell_exec("gpg --batch --yes --passphrase 'asix' --output " . escapeshellarg($base) . " --decrypt " . escapeshellarg($gpgFile));
        shell_exec("gunzip -f " . escapeshellarg($base));
        unlink($gpgFile);
        $mensaje = "<p>El archivo $archivo ha sido desbloqueado correctamente y el archivo GPG ha sido eliminado.</p>";
    }
}

// ELIMINAR UN ARCHIVO
if (isset($_GET['eliminar'])) {
    $archivoEliminar = $_GET['eliminar'];
    if (file_exists($directorio . '/' . $archivoEliminar)) {
        $mensaje = unlink($directorio . '/' . $archivoEliminar)
            ? "<p>El archivo $archivoEliminar ha sido eliminado correctamente.</p>"
            : "<p>No se pudo eliminar el archivo $archivoEliminar.</p>";
    } else {
        $mensaje = "<p>El archivo $archivoEliminar no existe.</p>";
    }
}

// LIMPIAR LOG
if (isset($_GET['limpiar_log'])) {
    $logFile = '/home/proyecto/backups/mysql_backup.log';
    file_put_contents($logFile, '');
    $mensaje = "<p>🧹 Log limpiado correctamente.</p>";
}