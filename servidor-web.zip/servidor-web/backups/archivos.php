<?php
function extraerNumero($archivo) {
    preg_match('/\d+/', $archivo, $coincidencias);
    return isset($coincidencias[0]) ? (int) $coincidencias[0] : 0;
}

$archivos = scandir($directorio);
$archivos = array_filter($archivos, fn($a) => $a !== '.' && $a !== '..');

if (isset($_GET['buscar'])) {
    $buscar   = strtolower($_GET['buscar']);
    $archivos = array_filter($archivos, fn($a) => strpos(strtolower($a), $buscar) !== false);
}

usort($archivos, function($a, $b) {
    // Extraer fecha del nombre: backup_caremind_db_2026-04-27_10-00-00.sql
    preg_match('/(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})/', $a, $matchA);
    preg_match('/(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})/', $b, $matchB);

    $fechaA = $matchA[1] ?? '0000-00-00_00-00-00';
    $fechaB = $matchB[1] ?? '0000-00-00_00-00-00';

    // Más nuevo primero
    if ($fechaA !== $fechaB) {
        return strcmp($fechaB, $fechaA);
    }

    // Misma fecha: sql > gz > gpg (abierto antes que cerrado)
    $orden = ['sql' => 1, 'gz' => 2, 'gpg' => 3];
    $pA = $orden[pathinfo($a, PATHINFO_EXTENSION)] ?? 4;
    $pB = $orden[pathinfo($b, PATHINFO_EXTENSION)] ?? 4;
    return $pA - $pB;
});
?>

<h2 style="margin-top:0;">📂 Archivos de Backup — caremind_db</h2>

<form method="GET" style="margin-bottom: 12px;">
    <input type="text" name="buscar" placeholder="Buscar archivo..."
           value="<?= isset($_GET['buscar']) ? htmlspecialchars($_GET['buscar']) : '' ?>"
           style="padding:6px; border:1px solid #ccc; border-radius:4px;">
    <button type="submit" style="padding:6px 12px;">Buscar</button>
    <button type="submit" name="eliminar_todo" value="1"
            onclick="return confirm('¿Seguro que deseas eliminar TODOS los archivos?')"
            style="padding:6px 12px; background:#e53935; color:white; border:none; border-radius:4px; cursor:pointer;">
        🗑️ Eliminar todo
    </button>
</form>

<ul style="list-style:none; padding:0; margin:0;">
<?php foreach ($archivos as $archivo):
    $ext      = pathinfo($archivo, PATHINFO_EXTENSION);
    $estilo   = 'padding:4px 0;';
    $emoticono = '';
    $botones  = '';

    if (!in_array($ext, ['sql','gz','gpg']) && !is_dir($directorio.'/'.$archivo)) {
        $emoticono = "⚠️"; $estilo .= ' color:red;';
    } elseif ($ext === 'sql') {
        $emoticono = "🗄️";
        $botones .= '<a href="?ver='      . urlencode($archivo) . '"><button>Ver</button></a> ';
        $botones .= '<a href="?bloquear=' . urlencode($archivo) . '"><button>Bloquear</button></a> ';
    } elseif ($ext === 'gz') {
        $emoticono = "🗜️";
    } elseif ($ext === 'gpg') {
        $emoticono = "🔐";
        $botones .= '<a href="?desbloquear=' . urlencode($archivo) . '"><button>Desbloquear</button></a> ';
    } elseif (is_dir($directorio.'/'.$archivo)) {
        $emoticono = "📁";
    }

    $botones .= '<a href="?eliminar=' . urlencode($archivo) . '" onclick="return confirm(\'¿Seguro?\')"><button>Eliminar</button></a>';
?>
    <li style="<?= $estilo ?>"><?= $emoticono ?> <?= htmlspecialchars($archivo) ?> <?= $botones ?></li>
<?php endforeach; ?>
</ul>

<?php if ($mensaje) echo $mensaje; ?>