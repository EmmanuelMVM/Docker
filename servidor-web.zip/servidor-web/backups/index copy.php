<?php
// Ruta de la carpeta que quieres analizar
$directorio = 'backups';
$directorioRemoto = 'remoto';
$mensaje = '';
$mensajeCron = '';

function extraerNumero($archivo) {
    preg_match('/\d+/', $archivo, $coincidencias);
    return isset($coincidencias[0]) ? (int) $coincidencias[0] : 0;
}

if (is_dir($directorio)) {

    // EJECUTAR SCRIPT COPIAR BACKUP
    if (isset($_GET['crear_backup'])) {
        $output = shell_exec("bash copiar_backup.sh 2>&1");
        $mensaje = "<p>✅ Copia de seguridad creada correctamente." . ($output ? " Salida: " . htmlspecialchars($output) : "") . "</p>";
    }

    // PROGRAMAR CRON
    if (isset($_POST['programar_cron'])) {
        $minuto  = isset($_POST['minuto'])  ? intval($_POST['minuto'])  : 0;
        $hora    = isset($_POST['hora'])    ? intval($_POST['hora'])    : 0;
        $diaMes  = isset($_POST['dia_mes']) ? trim($_POST['dia_mes'])   : '*';
        $mes     = isset($_POST['mes'])     ? trim($_POST['mes'])       : '*';
        $diaSem  = isset($_POST['dia_sem']) ? trim($_POST['dia_sem'])   : '*';

        $minuto  = max(0, min(59, $minuto));
        $hora    = max(0, min(23, $hora));
        $diaMes  = preg_match('/^(\*|[1-9]|[12]\d|3[01])$/', $diaMes)  ? $diaMes : '*';
        $mes     = preg_match('/^(\*|[1-9]|1[0-2])$/', $mes)           ? $mes    : '*';
        $diaSem  = preg_match('/^(\*|[0-6])$/', $diaSem)               ? $diaSem : '*';

        $rutaScript = realpath('copiar_backup.sh');
        $nuevaLinea = "$minuto $hora $diaMes $mes $diaSem bash $rutaScript";

        $crontabActual = shell_exec("crontab -l 2>/dev/null") ?? '';
        $lineas = explode("\n", $crontabActual);
        $lineas = array_filter($lineas, function($linea) use ($rutaScript) {
            return strpos($linea, $rutaScript) === false && strpos($linea, 'copiar_backup.sh') === false;
        });
        $lineas[] = $nuevaLinea;
        $nuevoCrontab = implode("\n", $lineas) . "\n";

        $tmpFile = tempnam(sys_get_temp_dir(), 'cron_');
        file_put_contents($tmpFile, $nuevoCrontab);
        shell_exec("crontab $tmpFile");
        unlink($tmpFile);

        $mensajeCron = "<p>✅ Cron programado correctamente: <code>$nuevaLinea</code></p>";
    }

    // ELIMINAR CRON
    if (isset($_GET['eliminar_cron'])) {
        $crontabActual = shell_exec("crontab -l 2>/dev/null") ?? '';
        $lineas = explode("\n", $crontabActual);
        $lineas = array_filter($lineas, function($linea) {
            return strpos($linea, 'copiar_backup.sh') === false;
        });
        $nuevoCrontab = implode("\n", $lineas) . "\n";
        $tmpFile = tempnam(sys_get_temp_dir(), 'cron_');
        file_put_contents($tmpFile, $nuevoCrontab);
        shell_exec("crontab $tmpFile");
        unlink($tmpFile);
        $mensajeCron = "<p>🗑️ Entrada del cron eliminada correctamente.</p>";
    }

    // Leer cron actual del script para mostrarlo
    $crontabActual = shell_exec("crontab -l 2>/dev/null") ?? '';
    $cronActivo = '';
    foreach (explode("\n", $crontabActual) as $linea) {
        if (strpos($linea, 'copiar_backup.sh') !== false) {
            $cronActivo = trim($linea);
            break;
        }
    }

    // ELIMINAR TODOS LOS ARCHIVOS
    if (isset($_GET['eliminar_todo'])) {
        $archivosEliminar = scandir($directorio);
        $eliminados = 0;
        $errores = 0;
        foreach ($archivosEliminar as $arch) {
            if ($arch === '.' || $arch === '..') continue;
            $ruta = $directorio . '/' . $arch;
            if (is_file($ruta)) {
                unlink($ruta) ? $eliminados++ : $errores++;
            }
        }
        $mensaje = "<p>Se eliminaron $eliminados archivo(s)." . ($errores ? " $errores no pudieron eliminarse." : "") . "</p>";
    }

    // VER SQL
    if (isset($_GET['ver'])) {
        $archivo = $_GET['ver'];
        if (file_exists($directorio . '/' . $archivo) && pathinfo($archivo, PATHINFO_EXTENSION) === 'sql') {
            shell_exec("gedit " . escapeshellarg($directorio . '/' . $archivo) . " > /dev/null 2>&1 &");
        } else {
            echo "Archivo no válido o no encontrado.";
        }
    }

    // BLOQUEAR SQL -> GZ -> GPG
    if (isset($_GET['bloquear'])) {
        $archivo = $_GET['bloquear'];
        if (file_exists($directorio . '/' . $archivo) && pathinfo($archivo, PATHINFO_EXTENSION) === 'sql') {
            $sqlFile = $directorio . '/' . $archivo;
            shell_exec("gzip -f " . escapeshellarg($sqlFile));
            $gzFile = $sqlFile . '.gz';
            shell_exec("gpg --batch --yes --passphrase 'asix' --symmetric --cipher-algo AES256 " . escapeshellarg($gzFile));
            unlink($gzFile);
            $mensaje = "<p>El archivo $archivo ha sido bloqueado correctamente.</p>";
        }
    }

    // DESBLOQUEAR GPG -> GZ -> SQL
    if (isset($_GET['desbloquear'])) {
        $archivo = $_GET['desbloquear'];
        if (file_exists($directorio . '/' . $archivo) && pathinfo($archivo, PATHINFO_EXTENSION) === 'gpg') {
            $gpgFile = $directorio . '/' . $archivo;
            $base = preg_replace('/\.gpg$/', '', $gpgFile);
            $gzFile = $base;
            shell_exec("gpg --batch --yes --passphrase 'asix' --output " . escapeshellarg($gzFile) . " --decrypt " . escapeshellarg($gpgFile));
            shell_exec("gunzip -f " . escapeshellarg($gzFile));
            unlink($gpgFile);
            $mensaje = "<p>El archivo $archivo ha sido desbloqueado correctamente y el archivo GPG ha sido eliminado.</p>";
        }
    }

    // COPIAR GPG
    if (isset($_GET['copiar'])) {
        $archivo = $_GET['copiar'];
        if (file_exists($directorio . '/' . $archivo) && pathinfo($archivo, PATHINFO_EXTENSION) === 'gpg') {
            $gpgFile = $directorio . '/' . $archivo;
            $destino = $directorioRemoto . '/' . $archivo;
            if (!is_dir($directorioRemoto)) {
                mkdir($directorioRemoto, 0777, true);
            }
            if (copy($gpgFile, $destino)) {
                $mensaje = "<p>El archivo $archivo ha sido copiado correctamente a la carpeta 'remoto'.</p>";
            } else {
                $mensaje = "<p>Hubo un error al copiar el archivo $archivo.</p>";
            }
        }
    }

    // ELIMINAR UN ARCHIVO
    if (isset($_GET['eliminar'])) {
        $archivoEliminar = $_GET['eliminar'];
        if (file_exists($directorio . '/' . $archivoEliminar)) {
            if (unlink($directorio . '/' . $archivoEliminar)) {
                $mensaje = "<p>El archivo $archivoEliminar ha sido eliminado correctamente.</p>";
            } else {
                $mensaje = "<p>No se pudo eliminar el archivo $archivoEliminar.</p>";
            }
        } else {
            $mensaje = "<p>El archivo $archivoEliminar no existe.</p>";
        }
    }

    // Obtener y filtrar archivos
    $archivos = scandir($directorio);
    $archivos = array_filter($archivos, function($archivo) {
        return $archivo != '.' && $archivo != '..';
    });

    if (isset($_GET['buscar'])) {
        $buscar = strtolower($_GET['buscar']);
        $archivos = array_filter($archivos, function($archivo) use ($buscar) {
            return strpos(strtolower($archivo), $buscar) !== false;
        });
    }

    usort($archivos, function($a, $b) use ($directorio) {
        $extA = pathinfo($a, PATHINFO_EXTENSION);
        $extB = pathinfo($b, PATHINFO_EXTENSION);
        $numeroA = extraerNumero($a);
        $numeroB = extraerNumero($b);
        if ($numeroA == $numeroB) {
            $prioridadA = ($extA == 'sql') ? 1 : (($extA == 'gz') ? 2 : (($extA == 'gpg') ? 3 : 4));
            $prioridadB = ($extB == 'sql') ? 1 : (($extB == 'gz') ? 2 : (($extB == 'gpg') ? 3 : 4));
            return $prioridadA - $prioridadB;
        }
        return $numeroB - $numeroA;
    });

    // Valores actuales del cron para pre-rellenar el formulario
    $valMinuto = 0; $valHora = 0; $valDiaMes = '*'; $valMes = '*'; $valDiaSem = '*';
    if ($cronActivo) {
        $partes = preg_split('/\s+/', $cronActivo);
        if (count($partes) >= 5) {
            $valMinuto = $partes[0];
            $valHora   = $partes[1];
            $valDiaMes = $partes[2];
            $valMes    = $partes[3];
            $valDiaSem = $partes[4];
        }
    }

    // ---- LAYOUT DE DOS COLUMNAS ----
    echo '
    <div style="display: flex; gap: 12px; align-items: flex-start; font-family: sans-serif;">

        <!-- COLUMNA IZQUIERDA: Buscador y lista -->
        <div style="flex: 1; min-width: 0;">
            <h2 style="margin-top:0;">📂 Archivos de Backup</h2>';

            echo '<form method="GET" style="margin-bottom: 12px;">
                    <input type="text" name="buscar" placeholder="Buscar archivo..."
                           value="' . (isset($_GET['buscar']) ? htmlspecialchars($_GET['buscar']) : '') . '"
                           style="padding: 6px; border: 1px solid #ccc; border-radius: 4px;">
                    <button type="submit" style="padding: 6px 12px;">Buscar</button>
                    <button type="submit" name="eliminar_todo" value="1"
                            onclick="return confirm(\'¿Seguro que deseas eliminar TODOS los archivos?\')"
                            style="padding: 6px 12px; background:#e53935; color:white; border:none; border-radius:4px; cursor:pointer;">
                        🗑️ Eliminar todo
                    </button>
                  </form>';

            echo '<ul style="list-style:none; padding:0; margin:0;">';
            foreach ($archivos as $archivo) {
                $ext = pathinfo($archivo, PATHINFO_EXTENSION);
                $botonVer = $botonBloquear = $botonDesbloquear = $botonCopiar = $botonEliminar = '';
                $estilo = $emoticono = '';

                if (!in_array($ext, ['sql', 'gz', 'gpg']) && !is_dir($directorio . '/' . $archivo)) {
                    $emoticono = "⚠️";
                    $estilo = 'style="color:red; padding: 4px 0;"';
                } elseif ($ext == 'sql') {
                    $emoticono = "🗄️";
                    $botonVer = '<a href="?ver=' . urlencode($archivo) . '"><button>Ver</button></a>';
                    $botonBloquear = '<a href="?bloquear=' . urlencode($archivo) . '"><button>Bloquear</button></a>';
                    $estilo = 'style="padding: 4px 0;"';
                } elseif ($ext == 'gz') {
                    $emoticono = "🗜️";
                    $estilo = 'style="padding: 4px 0;"';
                } elseif ($ext == 'gpg') {
                    $emoticono = "🔐";
                    $botonDesbloquear = '<a href="?desbloquear=' . urlencode($archivo) . '"><button>Desbloquear</button></a>';
                    $botonCopiar = '<a href="?copiar=' . urlencode($archivo) . '"><button>Copiar</button></a>';
                    $estilo = 'style="padding: 4px 0;"';
                } elseif (is_dir($directorio . '/' . $archivo)) {
                    $emoticono = "📁";
                    $estilo = 'style="padding: 4px 0;"';
                }

                $botonEliminar = '<a href="?eliminar=' . urlencode($archivo) . '" onclick="return confirm(\'¿Seguro que deseas eliminar este archivo?\')"><button>Eliminar</button></a>';
                echo "<li $estilo>$emoticono " . htmlspecialchars($archivo) . " $botonVer $botonBloquear $botonDesbloquear $botonCopiar $botonEliminar</li>";
            }
            echo '</ul>';

            if ($mensaje) echo $mensaje;

    echo '
        </div>

        <!-- COLUMNA DERECHA: Copia manual y cron -->
        <div style="width: 360px; flex-shrink: 0; display: flex; flex-direction: column; gap: 20px;">

            <!-- Copia manual -->
            <div style="border: 2px solid #4CAF50; border-radius: 8px; padding: 16px; background-color: #f9fff9;">
                <p style="margin: 0 0 10px 0; font-size: 16px; font-weight: bold;">🛡️ Crea una Copia de Seguridad Ahora</p>
                <a href="?crear_backup=1" onclick="return confirm(\'¿Deseas crear una copia de seguridad ahora?\')">
                    <button style="background-color: #4CAF50; color: white; padding: 10px 20px; font-size: 15px; border: none; border-radius: 5px; cursor: pointer; width: 100%;">
                        CREAR AHORA
                    </button>
                </a>
            </div>

            <!-- Programar cron -->
            <div style="border: 2px solid #2196F3; border-radius: 8px; padding: 16px; background-color: #f0f8ff;">
                <p style="margin: 0 0 12px 0; font-size: 16px; font-weight: bold;">🕐 Programar Copia Automática</p>';

                if ($cronActivo) {
                    echo '<p style="margin: 0 0 10px 0; font-size: 13px; color: #555;">
                            ⚙️ Cron activo: <code style="background:#e8e8e8; padding:2px 6px; border-radius:4px;">' . htmlspecialchars($cronActivo) . '</code>
                            &nbsp;<a href="?eliminar_cron=1" onclick="return confirm(\'¿Deseas eliminar la programación actual?\')">
                                <button style="background-color:#e53935; color:white; border:none; border-radius:4px; padding:3px 8px; cursor:pointer;">🗑️</button>
                            </a>
                          </p>';
                } else {
                    echo '<p style="margin: 0 0 10px 0; font-size: 13px; color: #999;">⚙️ Sin programación activa.</p>';
                }

                echo '
                <form method="POST" style="display: flex; flex-direction: column; gap: 10px;">
                    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                        <div style="display:flex; flex-direction:column; gap:3px;">
                            <label style="font-size:12px; font-weight:bold;">Minuto <span style="color:#888;">(0-59)</span></label>
                            <input type="number" name="minuto" min="0" max="59" value="' . htmlspecialchars($valMinuto) . '"
                                   style="width:60px; padding:5px; border:1px solid #ccc; border-radius:4px;">
                        </div>
                        <div style="display:flex; flex-direction:column; gap:3px;">
                            <label style="font-size:12px; font-weight:bold;">Hora <span style="color:#888;">(0-23)</span></label>
                            <input type="number" name="hora" min="0" max="23" value="' . htmlspecialchars($valHora) . '"
                                   style="width:60px; padding:5px; border:1px solid #ccc; border-radius:4px;">
                        </div>
                        <div style="display:flex; flex-direction:column; gap:3px;">
                            <label style="font-size:12px; font-weight:bold;">Día mes <span style="color:#888;">(1-31/*)</span></label>
                            <input type="text" name="dia_mes" value="' . htmlspecialchars($valDiaMes) . '"
                                   style="width:60px; padding:5px; border:1px solid #ccc; border-radius:4px;">
                        </div>
                        <div style="display:flex; flex-direction:column; gap:3px;">
                            <label style="font-size:12px; font-weight:bold;">Mes <span style="color:#888;">(1-12/*)</span></label>
                            <input type="text" name="mes" value="' . htmlspecialchars($valMes) . '"
                                   style="width:55px; padding:5px; border:1px solid #ccc; border-radius:4px;">
                        </div>
                        <div style="display:flex; flex-direction:column; gap:3px;">
                            <label style="font-size:12px; font-weight:bold;">Día sem <span style="color:#888;">(0-6/*)</span></label>
                            <input type="text" name="dia_sem" value="' . htmlspecialchars($valDiaSem) . '"
                                   style="width:55px; padding:5px; border:1px solid #ccc; border-radius:4px;">
                        </div>
                    </div>
                    <button type="submit" name="programar_cron"
                            style="background-color:#2196F3; color:white; padding:10px; font-size:14px; border:none; border-radius:5px; cursor:pointer; width:100%;">
                        📅 PROGRAMAR
                    </button>
                </form>
                <p style="margin: 8px 0 0 0; font-size: 11px; color: #888;">Usa <strong>*</strong> para "cualquier valor". Ej: <code>0 3 * * 1</code> = lunes a las 3:00.</p>';

                if ($mensajeCron) echo $mensajeCron;

    echo '
            </div>
        </div>

    </div>'; // fin layout dos columnas

} else {
    echo "El directorio no existe.";
}
?>