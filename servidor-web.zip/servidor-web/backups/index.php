<?php
$directorio       = '/home/proyecto/backups/mysql';
$directorioRemoto = 'backupuser@192.168.2.4:/home/backupuser/mysql_backups';
$mensaje          = '';
$mensajeCron      = '';

require 'acciones.php';
require 'cron.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Backups</title>
    <link rel="icon" type="image/x-icon" href="favicon.ico?v=1">
    <style>
        body { font-family: sans-serif; margin: 20px; }
        .layout { display: flex; gap: 12px; align-items: flex-start; }
        .col-izquierda { flex: 1; min-width: 0; }
        .col-derecha { width: 480px; flex-shrink: 0; display: flex; flex-direction: column; gap: 20px; }
    </style>
</head>
<body>

<div class="layout">
    <div class="col-izquierda">
        <?php require 'archivos.php'; ?>
    </div>
    <div class="col-derecha">
        <?php require 'vistas/backup_manual.php'; ?>
        <?php require 'vistas/cron_form.php'; ?>
    </div>
</div>

</body>
</html>