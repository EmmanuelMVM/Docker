<?php
require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

iniciarSesion();
requiereLogin();

$input  = json_decode(file_get_contents('php://input'), true) ?? [];
$accion = $_GET['accion'] ?? $input['accion'] ?? '';
$yo     = usuarioActual();
$db     = getDB();

// =============================================
// LISTAR MEDICAMENTOS
// =============================================
if ($accion === 'listar') {
    $idPaciente = (int)($_GET['paciente'] ?? $yo['id']);

    // Verificar acceso
    if ($idPaciente !== (int)$yo['id']) {
        if ($yo['rol'] === 'paciente') jsonResponse(['error' => 'Sin permisos'], 403);
        if ($yo['rol'] === 'cuidador') {
            $check = $db->prepare("SELECT id FROM cuidador_paciente WHERE id_cuidador=? AND id_paciente=?");
            $check->execute([$yo['id'], $idPaciente]);
            if (!$check->fetch()) jsonResponse(['error' => 'Sin permisos'], 403);
        }
    }

    $stmt = $db->prepare("
        SELECT m.*, 
               GROUP_CONCAT(CONCAT(h.id,'|',h.hora,'|',h.dias_semana) ORDER BY h.hora SEPARATOR ';;') AS horarios_raw
        FROM medicamentos m
        LEFT JOIN horarios h ON h.id_medicamento = m.id
        WHERE m.id_paciente = ? AND m.activo = 1
        GROUP BY m.id
        ORDER BY m.nombre
    ");
    $stmt->execute([$idPaciente]);
    $meds = $stmt->fetchAll();

    foreach ($meds as &$m) {
        $m['horarios'] = [];
        if ($m['horarios_raw']) {
            foreach (explode(';;', $m['horarios_raw']) as $h) {
                [$hid, $hora, $dias] = explode('|', $h);
                $m['horarios'][] = ['id' => $hid, 'hora' => $hora, 'dias_semana' => $dias];
            }
        }
        unset($m['horarios_raw']);
    }

    jsonResponse(['medicamentos' => $meds]);
}

// =============================================
// CREAR MEDICAMENTO
// =============================================
if ($accion === 'crear') {
    if ($yo['rol'] === 'paciente') jsonResponse(['error' => 'Los pacientes no pueden crear medicamentos'], 403);

    $idPaciente  = (int)($input['id_paciente'] ?? 0);
    $nombre      = trim($input['nombre'] ?? '');
    $principio   = trim($input['principio_activo'] ?? '');
    $dosis       = trim($input['dosis'] ?? '');
    $unidad      = $input['unidad'] ?? 'mg';
    $via         = $input['via_administracion'] ?? 'oral';
    $instrucciones = trim($input['instrucciones'] ?? '');
    $color       = $input['color'] ?? '#4F86C6';
    $fechaInicio = $input['fecha_inicio'] ?? date('Y-m-d');
    $fechaFin    = $input['fecha_fin'] ?? null;
    $horarios    = $input['horarios'] ?? [];

    if (!$idPaciente || !$nombre || !$dosis) {
        jsonResponse(['error' => 'Faltan campos obligatorios'], 400);
    }

    try {
        $db->beginTransaction();

        $stmt = $db->prepare("
            INSERT INTO medicamentos 
            (id_paciente, id_creado_por, nombre, principio_activo, dosis, unidad, via_administracion, instrucciones, color, fecha_inicio, fecha_fin)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
        ");
        $stmt->execute([$idPaciente, $yo['id'], $nombre, $principio, $dosis, $unidad, $via, $instrucciones, $color, $fechaInicio, $fechaFin]);
        $medId = $db->lastInsertId();

        foreach ($horarios as $h) {
            $hora = $h['hora'] ?? null;
            $dias = $h['dias_semana'] ?? '1234567';
            if ($hora) {
                $db->prepare("INSERT INTO horarios (id_medicamento, hora, dias_semana) VALUES (?,?,?)")
                   ->execute([$medId, $hora, $dias]);
            }
        }

        $db->commit();
        jsonResponse(['ok' => true, 'id' => $medId]);
    } catch (PDOException $e) {
        $db->rollBack();
        jsonResponse(['error' => 'Error al guardar: ' . $e->getMessage()], 500);
    }
}

// =============================================
// EDITAR MEDICAMENTO
// =============================================
if ($accion === 'editar') {
    if ($yo['rol'] === 'paciente') jsonResponse(['error' => 'Sin permisos'], 403);

    $id          = (int)($input['id'] ?? 0);
    $nombre      = trim($input['nombre'] ?? '');
    $dosis       = trim($input['dosis'] ?? '');
    $unidad      = $input['unidad'] ?? 'mg';
    $via         = $input['via_administracion'] ?? 'oral';
    $instrucciones = trim($input['instrucciones'] ?? '');
    $color       = $input['color'] ?? '#4F86C6';
    $fechaFin    = $input['fecha_fin'] ?? null;
    $horarios    = $input['horarios'] ?? [];

    if (!$id || !$nombre || !$dosis) jsonResponse(['error' => 'Faltan campos'], 400);

    try {
        $db->beginTransaction();

        $db->prepare("
            UPDATE medicamentos SET nombre=?, dosis=?, unidad=?, via_administracion=?, instrucciones=?, color=?, fecha_fin=?
            WHERE id=?
        ")->execute([$nombre, $dosis, $unidad, $via, $instrucciones, $color, $fechaFin, $id]);

        $db->prepare("DELETE FROM horarios WHERE id_medicamento = ?")->execute([$id]);

        foreach ($horarios as $h) {
            $hora = $h['hora'] ?? null;
            $dias = $h['dias_semana'] ?? '1234567';
            if ($hora) {
                $db->prepare("INSERT INTO horarios (id_medicamento, hora, dias_semana) VALUES (?,?,?)")
                   ->execute([$id, $hora, $dias]);
            }
        }

        $db->commit();
        jsonResponse(['ok' => true]);
    } catch (PDOException $e) {
        $db->rollBack();
        jsonResponse(['error' => 'Error al editar'], 500);
    }
}

// =============================================
// ELIMINAR (desactivar) MEDICAMENTO
// =============================================
if ($accion === 'eliminar') {
    if ($yo['rol'] === 'paciente') jsonResponse(['error' => 'Sin permisos'], 403);
    $id = (int)($input['id'] ?? $_GET['id'] ?? 0);
    if (!$id) jsonResponse(['error' => 'ID inválido'], 400);
    $db->prepare("UPDATE medicamentos SET activo = 0 WHERE id = ?")->execute([$id]);
    jsonResponse(['ok' => true]);
}

// =============================================
// REGISTRAR TOMA
// =============================================
if ($accion === 'registrar_toma') {
    $idToma  = (int)($input['id_toma'] ?? 0);
    $estado  = $input['estado'] ?? 'tomada';
    $notas   = trim($input['notas'] ?? '');

    if (!$idToma) jsonResponse(['error' => 'ID de toma inválido'], 400);

    $db->prepare("UPDATE tomas SET estado=?, fecha_tomada=NOW(), notas=? WHERE id=?")
       ->execute([$estado, $notas, $idToma]);

    jsonResponse(['ok' => true]);
}

// =============================================
// TOMAS DEL DÍA
// =============================================
if ($accion === 'tomas_hoy') {
    $idPaciente = (int)($_GET['paciente'] ?? $yo['id']);
    $fecha      = $_GET['fecha'] ?? date('Y-m-d');

    $stmt = $db->prepare("
        SELECT t.*, m.nombre AS med_nombre, m.dosis, m.unidad, m.color,
               h.hora
        FROM tomas t
        JOIN medicamentos m ON m.id = t.id_medicamento
        JOIN horarios h ON h.id = t.id_horario
        WHERE t.id_paciente = ?
          AND DATE(t.fecha_programada) = ?
        ORDER BY t.fecha_programada ASC
    ");
    $stmt->execute([$idPaciente, $fecha]);
    jsonResponse(['tomas' => $stmt->fetchAll()]);
}

// =============================================
// GENERAR TOMAS PENDIENTES DEL DÍA
// =============================================
if ($accion === 'generar_tomas') {
    if ($yo['rol'] === 'paciente') jsonResponse(['error' => 'Sin permisos'], 403);

    $idPaciente = (int)($input['paciente'] ?? 0);
    $fecha      = $input['fecha'] ?? date('Y-m-d');
    $diaSemana  = (string)date('N', strtotime($fecha)); // 1=Lunes, 7=Domingo

    $stmt = $db->prepare("
        SELECT h.id AS id_horario, h.hora, h.dias_semana, m.id AS id_medicamento
        FROM horarios h
        JOIN medicamentos m ON m.id = h.id_medicamento
        WHERE m.id_paciente = ? AND m.activo = 1
          AND m.fecha_inicio <= ? AND (m.fecha_fin IS NULL OR m.fecha_fin >= ?)
    ");
    $stmt->execute([$idPaciente, $fecha, $fecha]);
    $horarios = $stmt->fetchAll();

    $insertados = 0;
    foreach ($horarios as $h) {
        if (strpos($h['dias_semana'], $diaSemana) === false) continue;
        $fechaProgramada = "$fecha {$h['hora']}";

        // Evitar duplicados
        $existe = $db->prepare("SELECT id FROM tomas WHERE id_horario=? AND fecha_programada=?");
        $existe->execute([$h['id_horario'], $fechaProgramada]);
        if ($existe->fetch()) continue;

        $db->prepare("INSERT INTO tomas (id_horario, id_medicamento, id_paciente, fecha_programada) VALUES (?,?,?,?)")
           ->execute([$h['id_horario'], $h['id_medicamento'], $idPaciente, $fechaProgramada]);
        $insertados++;
    }

    jsonResponse(['ok' => true, 'insertados' => $insertados]);
}

jsonResponse(['error' => 'Acción no reconocida'], 400);
