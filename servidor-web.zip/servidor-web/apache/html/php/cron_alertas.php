<?php
/**
 * CAREMIND - Cron de Alertas
 * Ejecutar cada 5 minutos con crontab:
 * 
 *   crontab -e
 *   * /5 * * * * php /home/proyecto/servidor-web/apache/html/php/config.php >> /var/log/caremind_alertas.log 2>&1
 */

require_once __DIR__ . '/config.php';

$db  = getDB();
$now = new DateTime();

echo "[" . $now->format('Y-m-d H:i:s') . "] Iniciando revisión de alertas...\n";

// Buscar tomas que:
// - Están en estado 'pendiente'
// - Han superado el tiempo límite de alerta
// - No se ha enviado alerta aún
$limite = (clone $now)->modify('-' . MINUTOS_ALERTA . ' minutes')->format('Y-m-d H:i:s');

$stmt = $db->prepare("
    SELECT t.id, t.fecha_programada, t.id_paciente,
           m.nombre AS med_nombre, m.dosis, m.unidad,
           u.nombre AS pac_nombre, u.apellidos AS pac_apellidos, u.email AS pac_email,
           cuid.email AS cuid_email, cuid.nombre AS cuid_nombre
    FROM tomas t
    JOIN medicamentos m ON m.id = t.id_medicamento
    JOIN usuarios u ON u.id = t.id_paciente
    LEFT JOIN cuidador_paciente cp ON cp.id_paciente = t.id_paciente
    LEFT JOIN usuarios cuid ON cuid.id = cp.id_cuidador
    WHERE t.estado = 'pendiente'
      AND t.fecha_programada <= ?
      AND t.alerta_enviada = 0
");
$stmt->execute([$limite]);
$tomas = $stmt->fetchAll();

echo "Tomas pendientes con alerta: " . count($tomas) . "\n";

foreach ($tomas as $toma) {
    $pacNombre = $toma['pac_nombre'] . ' ' . $toma['pac_apellidos'];
    $hora      = (new DateTime($toma['fecha_programada']))->format('H:i');
    $asunto    = "⚠️ Toma olvidada: {$toma['med_nombre']}";

    $cuerpoHtml = "
    <div style='font-family:Arial,sans-serif;max-width:600px;margin:0 auto;'>
        <div style='background:#e53e3e;color:white;padding:20px;border-radius:8px 8px 0 0;'>
            <h2 style='margin:0;'>⚠️ Alerta de Medicamento Olvidado</h2>
        </div>
        <div style='background:#fff;border:1px solid #e2e8f0;padding:24px;border-radius:0 0 8px 8px;'>
            <p style='font-size:16px;'>El paciente <strong>{$pacNombre}</strong> 
               no ha tomado su medicamento programado para las <strong>{$hora}</strong>.</p>
            <div style='background:#fff5f5;border-left:4px solid #e53e3e;padding:16px;margin:16px 0;'>
                <p style='margin:0;'><strong>Medicamento:</strong> {$toma['med_nombre']}</p>
                <p style='margin:4px 0 0;'><strong>Dosis:</strong> {$toma['dosis']} {$toma['unidad']}</p>
                <p style='margin:4px 0 0;'><strong>Hora programada:</strong> {$hora}</p>
            </div>
            <p>Por favor, verifique el estado del paciente.</p>
            <p style='color:#718096;font-size:12px;margin-top:32px;'>
                Este es un mensaje automático de CareMind. 
                Han pasado más de " . MINUTOS_ALERTA . " minutos desde la hora programada.
            </p>
        </div>
    </div>";

    // Enviar al paciente
    $enviado = enviarEmail($toma['pac_email'], $asunto, $cuerpoHtml);
    echo "  → Email a paciente ({$toma['pac_email']}): " . ($enviado ? "OK" : "FALLO") . "\n";

    // Enviar al cuidador si existe
    if ($toma['cuid_email']) {
        $enviado2 = enviarEmail($toma['cuid_email'], $asunto, $cuerpoHtml);
        echo "  → Email a cuidador ({$toma['cuid_email']}): " . ($enviado2 ? "OK" : "FALLO") . "\n";
    }

    // Registrar en BD y marcar como alerta enviada
    $db->prepare("
        INSERT INTO alertas (id_toma, email_destino, enviado) VALUES (?, ?, ?)
    ")->execute([$toma['id'], $toma['pac_email'], $enviado ? 1 : 0]);

    $db->prepare("UPDATE tomas SET alerta_enviada = 1 WHERE id = ?")->execute([$toma['id']]);

    // Marcar como olvidada
    $db->prepare("UPDATE tomas SET estado = 'olvidada' WHERE id = ? AND estado = 'pendiente'")
       ->execute([$toma['id']]);
}

echo "[" . (new DateTime())->format('H:i:s') . "] Revisión completada.\n\n";
