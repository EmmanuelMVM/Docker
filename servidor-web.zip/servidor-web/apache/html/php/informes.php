<?php
require_once __DIR__ . '/config.php';

iniciarSesion();
requiereLogin();

$accion = $_GET['accion'] ?? '';
$yo     = usuarioActual();
$db     = getDB();

// =============================================
// HISTORIAL DE TOMAS (JSON)
// =============================================
if ($accion === 'historial') {
    $idPaciente  = (int)($_GET['paciente'] ?? $yo['id']);
    $desde       = $_GET['desde'] ?? date('Y-m-01');
    $hasta       = $_GET['hasta'] ?? date('Y-m-d');

    $stmt = $db->prepare("
        SELECT t.id, t.fecha_programada, t.fecha_tomada, t.estado, t.notas,
               m.nombre AS medicamento, m.dosis, m.unidad, m.color,
               u.nombre AS paciente
        FROM tomas t
        JOIN medicamentos m ON m.id = t.id_medicamento
        JOIN usuarios u ON u.id = t.id_paciente
        WHERE t.id_paciente = ?
          AND DATE(t.fecha_programada) BETWEEN ? AND ?
        ORDER BY t.fecha_programada DESC
    ");
    $stmt->execute([$idPaciente, $desde, $hasta]);
    jsonResponse(['historial' => $stmt->fetchAll()]);
}

// =============================================
// ESTADÍSTICAS
// =============================================
if ($accion === 'estadisticas') {
    $idPaciente = (int)($_GET['paciente'] ?? $yo['id']);
    $desde      = $_GET['desde'] ?? date('Y-m-01');
    $hasta      = $_GET['hasta'] ?? date('Y-m-d');

    $stmt = $db->prepare("
        SELECT 
            COUNT(*) AS total,
            SUM(estado = 'tomada') AS tomadas,
            SUM(estado = 'olvidada') AS olvidadas,
            SUM(estado = 'pospuesta') AS pospuestas,
            SUM(estado = 'pendiente') AS pendientes,
            ROUND(SUM(estado = 'tomada') / COUNT(*) * 100, 1) AS adherencia
        FROM tomas
        WHERE id_paciente = ?
          AND DATE(fecha_programada) BETWEEN ? AND ?
    ");
    $stmt->execute([$idPaciente, $desde, $hasta]);
    $stats = $stmt->fetch();

    // Por medicamento
    $stmt2 = $db->prepare("
        SELECT m.nombre, m.color,
               COUNT(*) AS total,
               SUM(t.estado = 'tomada') AS tomadas,
               ROUND(SUM(t.estado = 'tomada') / COUNT(*) * 100, 1) AS adherencia
        FROM tomas t
        JOIN medicamentos m ON m.id = t.id_medicamento
        WHERE t.id_paciente = ?
          AND DATE(t.fecha_programada) BETWEEN ? AND ?
        GROUP BY m.id
        ORDER BY adherencia ASC
    ");
    $stmt2->execute([$idPaciente, $desde, $hasta]);

    jsonResponse([
        'resumen'       => $stats,
        'por_medicamento' => $stmt2->fetchAll()
    ]);
}

// =============================================
// INFORME PDF (HTML para imprimir)
// =============================================
if ($accion === 'pdf') {
    $idPaciente = (int)($_GET['paciente'] ?? $yo['id']);
    $desde      = $_GET['desde'] ?? date('Y-m-01');
    $hasta      = $_GET['hasta'] ?? date('Y-m-d');

    $paciente = $db->prepare("SELECT nombre, apellidos, email FROM usuarios WHERE id = ?");
    $paciente->execute([$idPaciente]);
    $pac = $paciente->fetch();

    $stmt = $db->prepare("
        SELECT t.fecha_programada, t.fecha_tomada, t.estado, t.notas,
               m.nombre AS medicamento, m.dosis, m.unidad
        FROM tomas t
        JOIN medicamentos m ON m.id = t.id_medicamento
        WHERE t.id_paciente = ?
          AND DATE(t.fecha_programada) BETWEEN ? AND ?
        ORDER BY t.fecha_programada ASC
    ");
    $stmt->execute([$idPaciente, $desde, $hasta]);
    $tomas = $stmt->fetchAll();

    $stats = $db->prepare("
        SELECT COUNT(*) AS total, SUM(estado='tomada') AS tomadas,
               ROUND(SUM(estado='tomada')/COUNT(*)*100,1) AS adherencia
        FROM tomas WHERE id_paciente=? AND DATE(fecha_programada) BETWEEN ? AND ?
    ");
    $stats->execute([$idPaciente, $desde, $hasta]);
    $s = $stats->fetch();

    header('Content-Type: text/html; charset=utf-8');
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Informe CareMind - <?= htmlspecialchars($pac['nombre'].' '.$pac['apellidos']) ?></title>
        <style>
            * { margin:0; padding:0; box-sizing:border-box; }
            body { font-family: Arial, sans-serif; font-size: 13px; color: #333; padding: 20px; }
            .header { background: #4F86C6; color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
            .header h1 { font-size: 22px; }
            .header p  { opacity: .85; margin-top: 4px; }
            .stats { display: flex; gap: 16px; margin-bottom: 20px; }
            .stat { flex:1; background:#f0f4ff; border-radius:8px; padding:12px; text-align:center; }
            .stat .num { font-size:28px; font-weight:bold; color:#4F86C6; }
            .stat .label { font-size:11px; color:#666; margin-top:2px; }
            table { width:100%; border-collapse:collapse; }
            th { background:#4F86C6; color:white; padding:8px; text-align:left; font-size:12px; }
            td { padding:7px 8px; border-bottom:1px solid #eee; }
            tr:nth-child(even) td { background:#f8f9ff; }
            .badge { display:inline-block; padding:2px 8px; border-radius:999px; font-size:11px; font-weight:bold; }
            .tomada   { background:#c6f6d5; color:#22543d; }
            .olvidada { background:#fed7d7; color:#742a2a; }
            .pendiente{ background:#fefcbf; color:#744210; }
            .pospuesta{ background:#e9d8fd; color:#44337a; }
            .footer { margin-top:20px; font-size:11px; color:#999; text-align:center; }
            @media print { button { display:none; } }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>📋 Informe de Medicación — CareMind</h1>
            <p>Paciente: <?= htmlspecialchars($pac['nombre'].' '.$pac['apellidos']) ?> | 
               Período: <?= $desde ?> → <?= $hasta ?></p>
        </div>

        <div class="stats">
            <div class="stat"><div class="num"><?= $s['total'] ?></div><div class="label">Tomas programadas</div></div>
            <div class="stat"><div class="num"><?= $s['tomadas'] ?></div><div class="label">Tomas realizadas</div></div>
            <div class="stat"><div class="num"><?= $s['adherencia'] ?? 0 ?>%</div><div class="label">Adherencia</div></div>
        </div>

        <button onclick="window.print()" style="margin-bottom:16px;padding:8px 20px;background:#4F86C6;color:white;border:none;border-radius:6px;cursor:pointer;font-size:13px;">
            🖨️ Imprimir / Guardar PDF
        </button>

        <table>
            <thead>
                <tr>
                    <th>Fecha</th><th>Hora</th><th>Medicamento</th><th>Dosis</th><th>Estado</th><th>Tomada a las</th><th>Notas</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($tomas as $t): ?>
                <tr>
                    <td><?= date('d/m/Y', strtotime($t['fecha_programada'])) ?></td>
                    <td><?= date('H:i', strtotime($t['fecha_programada'])) ?></td>
                    <td><?= htmlspecialchars($t['medicamento']) ?></td>
                    <td><?= htmlspecialchars($t['dosis'].' '.$t['unidad']) ?></td>
                    <td><span class="badge <?= $t['estado'] ?>"><?= ucfirst($t['estado']) ?></span></td>
                    <td><?= $t['fecha_tomada'] ? date('H:i', strtotime($t['fecha_tomada'])) : '—' ?></td>
                    <td><?= htmlspecialchars($t['notas'] ?? '') ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <div class="footer">
            Generado por CareMind el <?= date('d/m/Y H:i') ?>
        </div>
    </body>
    </html>
    <?php
    exit;
}

jsonResponse(['error' => 'Acción no reconocida'], 400);
