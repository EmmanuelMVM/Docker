<?php
// =============================================
// CAREMIND - Configuración
// =============================================

// Sesiones seguras para HTTPS
ini_set('session.save_path', '/tmp');
ini_set('session.cookie_samesite', 'None');
ini_set('session.cookie_secure', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_path', '/');
ini_set('session.cookie_domain', 'caremind.test');

// Base de datos (valores del docker-compose.yml)
define('DB_HOST',    'mysql_db');
define('DB_NAME',    'caremind_db');
define('DB_USER',    'usuario');
define('DB_PASS',    'asix');
define('DB_CHARSET', 'utf8mb4');

// Email
define('MAIL_FROM',      'caremind@caremind.test');
define('MAIL_FROM_NAME', 'CareMind Alertas');

// App
define('APP_NAME',        'CareMind');
define('APP_URL',         'https://caremind.test');
define('SESSION_DURACION', 3600 * 8);
define('MINUTOS_ALERTA',   30);

date_default_timezone_set('Europe/Madrid');

// =============================================
// Conexión PDO
// =============================================
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die(json_encode(['error' => 'Error BD: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// =============================================
// Respuesta JSON
// =============================================
function jsonResponse(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// =============================================
// Sesión
// =============================================
function iniciarSesion(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'domain'   => 'caremind.test',
            'secure'   => true,
            'httponly' => true,
            'samesite' => 'None',
        ]);
        session_start();
    }
}

function usuarioLogueado(): bool {
    iniciarSesion();
    return isset($_SESSION['usuario_id']) && isset($_SESSION['expira']) && $_SESSION['expira'] > time();
}

function requiereLogin(): void {
    if (!usuarioLogueado()) {
        header('Location: ' . APP_URL . '/login.html');
        exit;
    }
}

function requiereRol(string ...$roles): void {
    requiereLogin();
    if (!in_array($_SESSION['rol'], $roles)) {
        jsonResponse(['error' => 'No tienes permisos para esta acción'], 403);
    }
}

function usuarioActual(): array {
    return [
        'id'     => $_SESSION['usuario_id'],
        'nombre' => $_SESSION['nombre'],
        'email'  => $_SESSION['email'],
        'rol'    => $_SESSION['rol'],
    ];
}

// =============================================
// Email con mailserver Docker
// =============================================
function enviarEmail(string $destino, string $asunto, string $cuerpoHtml): bool {
    $cuerpoTexto = strip_tags($cuerpoHtml);
    $boundary    = md5(time());

    $cabeceras  = "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM . ">\r\n";
    $cabeceras .= "MIME-Version: 1.0\r\n";
    $cabeceras .= "Content-Type: multipart/alternative; boundary=\"$boundary\"\r\n";

    $cuerpo  = "--$boundary\r\n";
    $cuerpo .= "Content-Type: text/plain; charset=UTF-8\r\n\r\n$cuerpoTexto\r\n\r\n";
    $cuerpo .= "--$boundary\r\n";
    $cuerpo .= "Content-Type: text/html; charset=UTF-8\r\n\r\n$cuerpoHtml\r\n\r\n";
    $cuerpo .= "--$boundary--";

    return mail($destino, '=?UTF-8?B?' . base64_encode($asunto) . '?=', $cuerpo, $cabeceras);
}
