<?php
require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

iniciarSesion();
$accion = $_GET['accion'] ?? $_POST['accion'] ?? '';
$input  = json_decode(file_get_contents('php://input'), true) ?? [];

// =============================================
// LOGIN
// =============================================
if ($accion === 'login') {
    $email    = trim($input['email'] ?? '');
    $password = $input['password'] ?? '';

    if (!$email || !$password) {
        jsonResponse(['error' => 'Email y contraseña son obligatorios'], 400);
    }

    $db   = getDB();
    $stmt = $db->prepare("SELECT * FROM usuarios WHERE email = ? AND activo = 1");
    $stmt->execute([$email]);
    $usuario = $stmt->fetch();

    if (!$usuario || !password_verify($password, $usuario['password_hash'])) {
        jsonResponse(['error' => 'Credenciales incorrectas'], 401);
    }

    $_SESSION['usuario_id'] = $usuario['id'];
    $_SESSION['nombre']     = $usuario['nombre'];
    $_SESSION['email']      = $usuario['email'];
    $_SESSION['rol']        = $usuario['rol'];
    $_SESSION['expira']     = time() + SESSION_DURACION;

    $db->prepare("UPDATE usuarios SET ultimo_acceso = NOW() WHERE id = ?")->execute([$usuario['id']]);

    jsonResponse([
        'ok'      => true,
        'usuario' => [
            'id'     => $usuario['id'],
            'nombre' => $usuario['nombre'],
            'email'  => $usuario['email'],
            'rol'    => $usuario['rol'],
        ]
    ]);
}

// =============================================
// LOGOUT
// =============================================
if ($accion === 'logout') {
    session_destroy();
    jsonResponse(['ok' => true]);
}

// =============================================
// SESIÓN ACTUAL
// =============================================
if ($accion === 'sesion') {
    if (usuarioLogueado()) {
        jsonResponse(['logueado' => true, 'usuario' => usuarioActual()]);
    } else {
        jsonResponse(['logueado' => false]);
    }
}

// =============================================
// REGISTRO (solo admin)
// =============================================
if ($accion === 'registro') {
    requiereRol('admin', 'cuidador');

    $nombre   = trim($input['nombre'] ?? '');
    $apellidos= trim($input['apellidos'] ?? '');
    $email    = trim($input['email'] ?? '');
    $password = $input['password'] ?? '';
    $rol      = $input['rol'] ?? 'paciente';

    if (!$nombre || !$email || !$password) {
        jsonResponse(['error' => 'Faltan campos obligatorios'], 400);
    }

    // Solo admin puede crear admins/cuidadores
    if (in_array($rol, ['admin', 'cuidador']) && $_SESSION['rol'] !== 'admin') {
        jsonResponse(['error' => 'Sin permisos para crear este rol'], 403);
    }

    $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    $db   = getDB();

    try {
        $stmt = $db->prepare("INSERT INTO usuarios (nombre, apellidos, email, password_hash, rol) VALUES (?,?,?,?,?)");
        $stmt->execute([$nombre, $apellidos, $email, $hash, $rol]);
        $nuevoId = $db->lastInsertId();
        jsonResponse(['ok' => true, 'id' => $nuevoId]);
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            jsonResponse(['error' => 'El email ya está registrado'], 409);
        }
        jsonResponse(['error' => 'Error al crear usuario'], 500);
    }
}

// =============================================
// LISTAR USUARIOS (admin/cuidador)
// =============================================
if ($accion === 'listar_usuarios') {
    requiereRol('admin', 'cuidador');
    $db = getDB();

    if ($_SESSION['rol'] === 'admin') {
        $stmt = $db->query("SELECT id, nombre, apellidos, email, rol, activo, fecha_registro, ultimo_acceso FROM usuarios ORDER BY nombre");
    } else {
        // Cuidador solo ve sus pacientes
        $stmt = $db->prepare("
            SELECT u.id, u.nombre, u.apellidos, u.email, u.rol, u.activo, u.fecha_registro, u.ultimo_acceso
            FROM usuarios u
            JOIN cuidador_paciente cp ON cp.id_paciente = u.id
            WHERE cp.id_cuidador = ?
        ");
        $stmt->execute([$_SESSION['usuario_id']]);
    }

    jsonResponse(['usuarios' => $stmt->fetchAll()]);
}

// =============================================
// ASIGNAR CUIDADOR A PACIENTE
// =============================================
if ($accion === 'asignar_cuidador') {
    requiereRol('admin');
    $idCuidador = (int)($input['id_cuidador'] ?? 0);
    $idPaciente = (int)($input['id_paciente'] ?? 0);

    if (!$idCuidador || !$idPaciente) jsonResponse(['error' => 'IDs inválidos'], 400);

    $db = getDB();
    try {
        $db->prepare("INSERT IGNORE INTO cuidador_paciente (id_cuidador, id_paciente) VALUES (?,?)")
           ->execute([$idCuidador, $idPaciente]);
        jsonResponse(['ok' => true]);
    } catch (PDOException $e) {
        jsonResponse(['error' => 'Error al asignar'], 500);
    }
}

// =============================================
// EDITAR / DESACTIVAR USUARIO
// =============================================
if ($accion === 'editar_usuario') {
    requiereRol('admin');
    $id     = (int)($input['id'] ?? 0);
    $activo = isset($input['activo']) ? (int)$input['activo'] : null;
    $rol    = $input['rol'] ?? null;

    if (!$id) jsonResponse(['error' => 'ID inválido'], 400);

    $db = getDB();
    if ($activo !== null) {
        $db->prepare("UPDATE usuarios SET activo = ? WHERE id = ?")->execute([$activo, $id]);
    }
    if ($rol) {
        $db->prepare("UPDATE usuarios SET rol = ? WHERE id = ?")->execute([$rol, $id]);
    }
    jsonResponse(['ok' => true]);
}

jsonResponse(['error' => 'Acción no reconocida'], 400);
