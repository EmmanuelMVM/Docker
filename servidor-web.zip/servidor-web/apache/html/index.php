<?php
$conn = pg_connect("host=postgres_db dbname=basedatos user=usuario password=password");

if ($conn) {
	echo "Conectado a PostgreSQL correctamente";
} else {
	echo "Error de coneción";
}
?>
