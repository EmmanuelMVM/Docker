-- =============================================
-- CAREMIND - Base de Datos MySQL
-- =============================================

CREATE DATABASE IF NOT EXISTS caremind CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE caremind;

-- =============================================
-- TABLA: usuarios
-- =============================================
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellidos VARCHAR(150) NOT NULL,
    email VARCHAR(200) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    rol ENUM('admin', 'cuidador', 'paciente') NOT NULL DEFAULT 'paciente',
    activo TINYINT(1) DEFAULT 1,
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
    ultimo_acceso DATETIME NULL
) ENGINE=InnoDB;

-- =============================================
-- TABLA: relaciones cuidador-paciente
-- =============================================
CREATE TABLE cuidador_paciente (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_cuidador INT NOT NULL,
    id_paciente INT NOT NULL,
    fecha_asignacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_cuidador) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_paciente) REFERENCES usuarios(id) ON DELETE CASCADE,
    UNIQUE KEY unico_par (id_cuidador, id_paciente)
) ENGINE=InnoDB;

-- =============================================
-- TABLA: medicamentos
-- =============================================
CREATE TABLE medicamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_paciente INT NOT NULL,
    id_creado_por INT NOT NULL,
    nombre VARCHAR(200) NOT NULL,
    principio_activo VARCHAR(200) NULL,
    dosis VARCHAR(100) NOT NULL,
    unidad VARCHAR(50) NOT NULL DEFAULT 'mg',
    via_administracion ENUM('oral','sublingual','topica','inyectable','inhalada','oftálmica','ótica','nasal','rectal') DEFAULT 'oral',
    instrucciones TEXT NULL,
    color VARCHAR(7) DEFAULT '#5B8DEF',
    activo TINYINT(1) DEFAULT 1,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NULL,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_paciente) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_creado_por) REFERENCES usuarios(id)
) ENGINE=InnoDB;

-- =============================================
-- TABLA: horarios de toma
-- =============================================
CREATE TABLE horarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_medicamento INT NOT NULL,
    hora TIME NOT NULL,
    dias_semana VARCHAR(20) NOT NULL DEFAULT '1234567',
    FOREIGN KEY (id_medicamento) REFERENCES medicamentos(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =============================================
-- TABLA: registro de tomas
-- =============================================
CREATE TABLE tomas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_horario INT NOT NULL,
    id_medicamento INT NOT NULL,
    id_paciente INT NOT NULL,
    fecha_programada DATETIME NOT NULL,
    fecha_tomada DATETIME NULL,
    estado ENUM('pendiente','tomada','olvidada','pospuesta') DEFAULT 'pendiente',
    notas TEXT NULL,
    alerta_enviada TINYINT(1) DEFAULT 0,
    FOREIGN KEY (id_horario) REFERENCES horarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_medicamento) REFERENCES medicamentos(id) ON DELETE CASCADE,
    FOREIGN KEY (id_paciente) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =============================================
-- TABLA: alertas enviadas
-- =============================================
CREATE TABLE alertas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_toma INT NOT NULL,
    email_destino VARCHAR(200) NOT NULL,
    fecha_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
    enviado TINYINT(1) DEFAULT 0,
    error TEXT NULL,
    FOREIGN KEY (id_toma) REFERENCES tomas(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =============================================
-- TABLA: sesiones
-- =============================================
CREATE TABLE sesiones (
    id VARCHAR(128) PRIMARY KEY,
    id_usuario INT NOT NULL,
    ip VARCHAR(45) NULL,
    user_agent TEXT NULL,
    fecha_inicio DATETIME DEFAULT CURRENT_TIMESTAMP,
    fecha_expira DATETIME NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =============================================
-- USUARIOS INICIALES
-- Contraseña de ambos: asix
-- =============================================
INSERT INTO usuarios (nombre, apellidos, email, password_hash, rol) VALUES
('Emmanuel', 'Admin', 'emmanuel@caremind.test', '$2b$12$G6wktmIO828orPR.SXIEEe.MCdTR6rSJjMXW8B5BZs9ptMHayrQke', 'admin'),
('Lucas', 'Paciente', 'lucas@caremind.test', '$2b$12$/mp.MrhTS7meA2yc.wz0ouv4p7CgGFB0iSi2/NG3pT.D2yXipQChG', 'paciente');

-- Asignar Emmanuel como cuidador de Lucas
INSERT INTO cuidador_paciente (id_cuidador, id_paciente) VALUES (1, 2);

-- =============================================
-- ÍNDICES
-- =============================================
CREATE INDEX idx_tomas_paciente ON tomas(id_paciente);
CREATE INDEX idx_tomas_fecha    ON tomas(fecha_programada);
CREATE INDEX idx_tomas_estado   ON tomas(estado);
CREATE INDEX idx_meds_paciente  ON medicamentos(id_paciente);
