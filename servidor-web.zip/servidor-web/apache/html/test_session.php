<?php
ini_set('session.save_path', '/tmp');
session_start();

if (isset($_GET['set'])) {
    $_SESSION['usuario_id'] = 1;
    $_SESSION['nombre'] = 'Emmanuel';
    echo json_encode(['accion' => 'guardado', 'session_id' => session_id()]);
} else {
    echo json_encode([
        'session_id' => session_id(),
        'contenido'  => $_SESSION,
        'cookies'    => $_COOKIE
    ]);
}
