# 📋 GUÍA DE INSTALACIÓN — CareMind
# Ubuntu Desktop · PHP · MySQL · msmtp

---

## 👥 USUARIOS INICIALES

| Nombre   | Email                  | Contraseña | Rol      |
|----------|------------------------|------------|----------|
| Emmanuel | emmanuel@caremind.test | asix       | Admin    |
| Lucas    | lucas@caremind.test    | asix       | Paciente |

---

## 🔧 PASO 1: Instalar dependencias

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y apache2 php php-mysql php-mbstring php-json libapache2-mod-php mysql-server msmtp msmtp-mta
sudo systemctl enable --now apache2
```

---

## 🗄️ PASO 2: Configurar MySQL

```bash
sudo mysql_secure_installation
sudo mysql -u root -p
```

Dentro de MySQL:
```sql
CREATE DATABASE caremind CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'caremind_user'@'localhost' IDENTIFIED BY 'TuPasswordSegura123!';
GRANT ALL PRIVILEGES ON caremind.* TO 'caremind_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

Importar esquema:
```bash
sudo mysql -u caremind_user -p caremind < /var/www/html/caremind/sql/caremind.sql
```

---

## 📂 PASO 3: Copiar archivos

```bash
sudo mkdir -p /var/www/html/caremind
sudo cp -r /ruta/proyecto/caremind/* /var/www/html/caremind/
sudo chown -R www-data:www-data /var/www/html/caremind
sudo chmod -R 755 /var/www/html/caremind
```

---

## ⚙️ PASO 4: Editar config.php

```bash
sudo nano /var/www/html/caremind/php/config.php
```

Cambia:
```php
define('DB_USER', 'caremind_user');
define('DB_PASS', 'TuPasswordSegura123!');
define('MAIL_FROM', 'tu_email@gmail.com');
define('APP_URL', 'http://localhost/caremind');
```

---

## 📧 PASO 5: Email con msmtp

```bash
sudo nano /etc/msmtprc
# Pega el contenido de msmtprc.ejemplo con tus datos de Gmail
sudo chmod 600 /etc/msmtprc
sudo chown www-data:www-data /etc/msmtprc
```

Contraseña de app Gmail: myaccount.google.com → Seguridad → Contraseñas de aplicación

---

## ⏰ PASO 6: Cron alertas

```bash
sudo crontab -u www-data -e
# Añadir:
*/5 * * * * php /var/www/html/caremind/php/cron_alertas.php >> /var/log/caremind.log 2>&1
```

---

## ✅ Acceso

URL: http://localhost/caremind/login.html

Emmanuel (admin): emmanuel@caremind.test / asix
Lucas (paciente): lucas@caremind.test / asix

---

## 🐛 Error de conexión a BD

```bash
# Ver error exacto:
curl http://localhost/caremind/php/auth.php?accion=sesion

# Probar credenciales MySQL:
mysql -u caremind_user -p caremind -e "SELECT email, rol FROM usuarios;"
```
