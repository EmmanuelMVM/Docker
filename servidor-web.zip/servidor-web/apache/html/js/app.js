// =============================================
// CAREMIND - Lógica principal
// =============================================

let usuarioActual = null;
let pacienteSeleccionado = null;

document.addEventListener('DOMContentLoaded', async () => {
    const sesion = await api('auth.php?accion=sesion');
    if (!sesion.logueado) { window.location.href = 'login.html'; return; }

    usuarioActual = sesion.usuario;
    if (usuarioActual.rol === 'paciente') pacienteSeleccionado = usuarioActual.id;

    document.getElementById('user-name').textContent   = usuarioActual.nombre;
    document.getElementById('user-role').textContent   = usuarioActual.rol;
    document.getElementById('user-avatar').textContent = usuarioActual.nombre.charAt(0).toUpperCase();

    if (usuarioActual.rol === 'paciente') {
        document.getElementById('nav-usuarios').classList.add('hidden');
        document.getElementById('nav-gestion-label').classList.add('hidden');
    }

    const hoy = new Date();
    document.getElementById('fecha-hoy').textContent = hoy.toLocaleDateString('es-ES', { weekday:'long', day:'numeric', month:'long' });
    document.getElementById('fecha-tomas').value = hoy.toISOString().split('T')[0];

    const primerDiaMes = new Date(hoy.getFullYear(), hoy.getMonth(), 1).toISOString().split('T')[0];
    document.getElementById('hist-desde').value = primerDiaMes;
    document.getElementById('hist-hasta').value = hoy.toISOString().split('T')[0];
    document.getElementById('inf-desde').value  = primerDiaMes;
    document.getElementById('inf-hasta').value  = hoy.toISOString().split('T')[0];

    if (usuarioActual.rol !== 'paciente') await cargarSelectorPacienteGlobal();

    cargarDashboard();
});

// =============================================
// SELECTOR DE PACIENTE GLOBAL
// =============================================
async function cargarSelectorPacienteGlobal() {
    const result    = await api('auth.php?accion=listar_usuarios');
    const pacientes = (result.usuarios || []).filter(u => u.rol === 'paciente' && u.activo == 1);
    if (!pacientes.length) return;

    pacienteSeleccionado = pacientes[0].id;

    const topbar = document.querySelector('.topbar');
    const div = document.createElement('div');
    div.style.cssText = 'display:flex;align-items:center;gap:8px;';
    div.innerHTML = `
        <label style="font-size:12px;font-weight:700;color:#718096;white-space:nowrap;">👤 Paciente:</label>
        <select id="selector-paciente-global" class="form-control" style="width:auto;padding:6px 12px;font-size:13px;" onchange="cambiarPaciente(parseInt(this.value))">
            ${pacientes.map(p => `<option value="${p.id}">${p.nombre} ${p.apellidos}</option>`).join('')}
        </select>
    `;
    topbar.appendChild(div);
}

function cambiarPaciente(id) {
    pacienteSeleccionado = id;
    const activa = document.querySelector('[id^="sec-"]:not(.hidden)');
    if (!activa) return;
    const nombre = activa.id.replace('sec-', '');
    if (nombre === 'dashboard')    cargarDashboard();
    if (nombre === 'tomas')        cargarTomas();
    if (nombre === 'medicamentos') cargarMedicamentos();
    if (nombre === 'historial')    cargarHistorial();
    if (nombre === 'informes')     cargarEstadisticas();
}

// =============================================
// API HELPER
// =============================================
async function api(endpoint, method = 'GET', body = null) {
    const opts = { method, headers: { 'Content-Type': 'application/json' } };
    if (body) opts.body = JSON.stringify(body);
    const r = await fetch('php/' + endpoint, opts);
    return r.json();
}

// =============================================
// NAVEGACIÓN
// =============================================
function mostrarSeccion(nombre) {
    document.querySelectorAll('[id^="sec-"]').forEach(s => s.classList.add('hidden'));
    document.getElementById('sec-' + nombre).classList.remove('hidden');
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    event?.currentTarget?.classList.add('active');

    const titulos = { dashboard:'Dashboard', tomas:'Tomas del día', medicamentos:'Medicamentos', historial:'Historial', usuarios:'Usuarios', informes:'Estadísticas e Informes' };
    document.getElementById('page-title').textContent = titulos[nombre] || nombre;

    if (nombre === 'tomas')        cargarTomas();
    if (nombre === 'medicamentos') cargarMedicamentos();
    if (nombre === 'historial')    cargarHistorial();
    if (nombre === 'usuarios')     cargarUsuarios();
    if (nombre === 'informes')     cargarEstadisticas();
}

function logout() {
    api('auth.php?accion=logout').then(() => window.location.href = 'login.html');
}

// =============================================
// DASHBOARD
// =============================================
async function cargarDashboard() {
    if (!pacienteSeleccionado) return;
    const hoy   = new Date().toISOString().split('T')[0];
    const tomas = await api(`medicamentos.php?accion=tomas_hoy&paciente=${pacienteSeleccionado}&fecha=${hoy}`);
    const meds  = await api(`medicamentos.php?accion=listar&paciente=${pacienteSeleccionado}`);
    const lista  = tomas.tomas || [];
    const tomadas    = lista.filter(t => t.estado === 'tomada').length;
    const olvidadas  = lista.filter(t => t.estado === 'olvidada').length;
    const pendientes = lista.filter(t => t.estado === 'pendiente').length;

    document.getElementById('stats-cards').innerHTML = `
        <div class="stat-card"><div class="stat-icon" style="background:#EBF8FF;"><img src="img/iconos/pill_color.png" style="width:28px;height:28px;object-fit:contain;"></div><div><div class="num" style="color:#3182CE;">${(meds.medicamentos||[]).length}</div><div class="label">Medicamentos activos</div></div></div>
        <div class="stat-card"><div class="stat-icon" style="background:#F0FFF4;"><img src="img/iconos/check_color.png" style="width:28px;height:28px;object-fit:contain;"></div><div><div class="num" style="color:#38A169;">${tomadas}</div><div class="label">Tomas realizadas hoy</div></div></div>
        <div class="stat-card"><div class="stat-icon" style="background:#FFFAF0;"><img src="img/iconos/hourglass.png" style="width:28px;height:28px;object-fit:contain;"></div><div><div class="num" style="color:#D69E2E;">${pendientes}</div><div class="label">Tomas pendientes</div></div></div>
        <div class="stat-card"><div class="stat-icon" style="background:#FFF5F5;"><img src="img/iconos/warning.png" style="width:28px;height:28px;object-fit:contain;"></div><div><div class="num" style="color:#E53E3E;">${olvidadas}</div><div class="label">Tomas olvidadas</div></div></div>
    `;

    const proximas = lista.filter(t => t.estado === 'pendiente').slice(0, 4);
    document.getElementById('dash-tomas-hoy').innerHTML = proximas.length
        ? proximas.map(t => tomaHtml(t, true)).join('')
        : '<p class="text-muted text-sm" style="padding:16px 0;">No hay tomas pendientes 🎉</p>';

    const medsLista = (meds.medicamentos || []).slice(0, 4);
    document.getElementById('dash-meds').innerHTML = medsLista.length
        ? medsLista.map(m => `<div class="med-card" style="margin-bottom:10px;"><div class="med-dot" style="background:${m.color}"></div><div><div class="med-name">${m.nombre}</div><div class="med-dosis">${m.dosis} ${m.unidad} · ${m.via_administracion}</div></div></div>`).join('')
        : '<p class="text-muted text-sm" style="padding:16px 0;">Sin medicamentos registrados</p>';
}

// =============================================
// TOMAS
// =============================================
async function cargarTomas() {
    if (!pacienteSeleccionado) return;
    const fecha  = document.getElementById('fecha-tomas').value;
    const result = await api(`medicamentos.php?accion=tomas_hoy&paciente=${pacienteSeleccionado}&fecha=${fecha}`);
    const lista  = result.tomas || [];
    const cont   = document.getElementById('lista-tomas');

    if (!lista.length) {
        cont.innerHTML = `<div style="text-align:center;padding:40px;color:#718096;"><div style="font-size:48px;">📭</div><p>No hay tomas programadas para este día.</p>${usuarioActual.rol !== 'paciente' ? `<button class="btn btn-primary" style="margin-top:12px;" onclick="generarTomas('${fecha}')">Generar tomas del día</button>` : ''}</div>`;
        return;
    }
    cont.innerHTML = lista.map(t => tomaHtml(t, false)).join('');
}

function tomaHtml(t, mini = false) {
    const hora    = t.hora || t.fecha_programada?.split(' ')[1]?.substring(0,5);
    const estado  = t.estado;
    const acciones = estado === 'pendiente' && !mini ? `<div class="toma-acciones"><button class="btn btn-success btn-sm" onclick="registrarToma(${t.id},'tomada')">✓ Tomada</button><button class="btn btn-secondary btn-sm" onclick="registrarToma(${t.id},'pospuesta')">⏰ Posponer</button></div>` : '';
    return `<div class="toma-item ${estado}" id="toma-${t.id}"><div class="toma-hora">${hora}</div><div style="width:8px;height:8px;border-radius:50%;background:${t.color||'#2E86AB'};flex-shrink:0;"></div><div class="toma-info"><div class="toma-med">${t.med_nombre||t.medicamento}</div><div class="toma-dosis">${t.dosis} ${t.unidad}</div></div><span class="badge badge-${estado}">${ucfirst(estado)}</span>${acciones}</div>`;
}

async function registrarToma(id, estado) {
    await api('medicamentos.php', 'POST', { accion: 'registrar_toma', id_toma: id, estado });
    cargarTomas(); cargarDashboard();
}

async function generarTomas(fecha) {
    await api('medicamentos.php', 'POST', { accion: 'generar_tomas', paciente: pacienteSeleccionado, fecha });
    cargarTomas();
}

// =============================================
// MEDICAMENTOS
// =============================================
async function cargarMedicamentos() {
    if (!pacienteSeleccionado) {
        document.getElementById('lista-medicamentos').innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:40px;color:#718096;">Selecciona un paciente.</div>';
        return;
    }
    const result = await api(`medicamentos.php?accion=listar&paciente=${pacienteSeleccionado}`);
    const lista  = result.medicamentos || [];
    const cont   = document.getElementById('lista-medicamentos');
    const puedeEditar = usuarioActual.rol !== 'paciente';

    if (!lista.length) {
        cont.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:40px;color:#718096;"><div style="font-size:48px;">💊</div><p>No hay medicamentos registrados para este paciente.</p></div>`;
        document.getElementById('btn-nuevo-med').style.display = puedeEditar ? '' : 'none';
        return;
    }

    cont.innerHTML = lista.map(m => `
        <div class="med-card">
            <div class="med-dot" style="background:${m.color};width:20px;height:20px;"></div>
            <div style="flex:1;">
                <div class="med-name">${m.nombre}</div>
                <div class="med-dosis">${m.dosis} ${m.unidad} · ${m.via_administracion}</div>
                ${m.instrucciones ? `<div style="font-size:11px;color:#718096;margin-top:4px;">${m.instrucciones}</div>` : ''}
                <div class="med-horarios">${(m.horarios||[]).map(h => `<span class="hora-pill">🕐 ${h.hora.substring(0,5)}</span>`).join('')}</div>
            </div>
            ${puedeEditar ? `<div style="display:flex;flex-direction:column;gap:4px;"><button class="btn btn-danger btn-sm btn-icon" onclick="eliminarMed(${m.id})" title="Eliminar">🗑️</button></div>` : ''}
        </div>`).join('');
    document.getElementById('btn-nuevo-med').style.display = puedeEditar ? '' : 'none';
}

async function abrirModalMed() {
    ['med-nombre','med-principio','med-dosis','med-instrucciones'].forEach(id => document.getElementById(id).value = '');
    document.getElementById('med-color').value  = '#2E86AB';
    document.getElementById('med-inicio').value = new Date().toISOString().split('T')[0];
    document.getElementById('med-fin').value    = '';
    document.getElementById('horarios-lista').innerHTML = '';
    document.getElementById('modal-med-titulo').textContent = 'Nuevo medicamento';
    document.getElementById('modal-med-alerta').classList.add('hidden');

    const usuarios  = await api('auth.php?accion=listar_usuarios');
    const pacientes = (usuarios.usuarios || []).filter(u => u.rol === 'paciente' && u.activo == 1);
    document.getElementById('med-paciente').innerHTML = pacientes.map(p =>
        `<option value="${p.id}" ${p.id == pacienteSeleccionado ? 'selected' : ''}>${p.nombre} ${p.apellidos}</option>`
    ).join('');

    document.getElementById('modal-med').classList.remove('hidden');
    agregarHorario();
}

function agregarHorario() {
    const cont = document.getElementById('horarios-lista');
    const div  = document.createElement('div');
    div.style.cssText = 'display:flex;gap:8px;align-items:center;margin-bottom:8px;';
    div.innerHTML = `
        <input type="time" class="form-control hor-hora" style="width:auto;" value="08:00">
        <select class="form-control hor-dias" style="width:auto;font-size:12px;">
            <option value="1234567">Todos los días</option>
            <option value="12345">Lunes a Viernes</option>
            <option value="67">Fin de semana</option>
            <option value="135">Lunes, Mié, Vie</option>
            <option value="1">Solo Lunes</option>
        </select>
        <button class="btn btn-danger btn-icon btn-sm" onclick="this.parentElement.remove()">✕</button>
    `;
    cont.appendChild(div);
}

async function guardarMedicamento() {
    const alerta = document.getElementById('modal-med-alerta');
    alerta.classList.add('hidden');
    const horarios = Array.from(document.querySelectorAll('#horarios-lista > div')).map(div => ({
        hora: div.querySelector('.hor-hora').value,
        dias_semana: div.querySelector('.hor-dias').value
    }));
    const data = {
        accion: 'crear',
        id_paciente:        parseInt(document.getElementById('med-paciente').value),
        nombre:             document.getElementById('med-nombre').value.trim(),
        principio_activo:   document.getElementById('med-principio').value.trim(),
        dosis:              document.getElementById('med-dosis').value.trim(),
        unidad:             document.getElementById('med-unidad').value,
        via_administracion: document.getElementById('med-via').value,
        instrucciones:      document.getElementById('med-instrucciones').value.trim(),
        color:              document.getElementById('med-color').value,
        fecha_inicio:       document.getElementById('med-inicio').value,
        fecha_fin:          document.getElementById('med-fin').value || null,
        horarios
    };
    if (!data.nombre || !data.dosis || !data.id_paciente) {
        alerta.textContent = '⚠️ Rellena los campos obligatorios.';
        alerta.classList.remove('hidden'); return;
    }
    const res = await api('medicamentos.php', 'POST', data);
    if (res.ok) {
        pacienteSeleccionado = data.id_paciente;
        const sel = document.getElementById('selector-paciente-global');
        if (sel) sel.value = pacienteSeleccionado;
        cerrarModal('modal-med');
        cargarMedicamentos();
    } else {
        alerta.textContent = '⚠️ ' + (res.error || 'Error al guardar');
        alerta.classList.remove('hidden');
    }
}

async function eliminarMed(id) {
    if (!confirm('¿Eliminar este medicamento?')) return;
    await api('medicamentos.php', 'POST', { accion: 'eliminar', id });
    cargarMedicamentos();
}

// =============================================
// HISTORIAL
// =============================================
async function cargarHistorial() {
    if (!pacienteSeleccionado) return;
    const desde  = document.getElementById('hist-desde').value;
    const hasta  = document.getElementById('hist-hasta').value;
    const result = await api(`informes.php?accion=historial&paciente=${pacienteSeleccionado}&desde=${desde}&hasta=${hasta}`);
    const lista  = result.historial || [];
    const tbody  = document.getElementById('tabla-historial');
    if (!lista.length) { tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:24px;color:#718096;">Sin registros en este período</td></tr>'; return; }
    tbody.innerHTML = lista.map(t => {
        const fp = new Date(t.fecha_programada);
        const ft = t.fecha_tomada ? new Date(t.fecha_tomada) : null;
        return `<tr><td>${fp.toLocaleDateString('es-ES')}</td><td>${fp.toLocaleTimeString('es-ES',{hour:'2-digit',minute:'2-digit'})}</td><td><strong>${t.medicamento}</strong></td><td>${t.dosis} ${t.unidad}</td><td><span class="badge badge-${t.estado}">${ucfirst(t.estado)}</span></td><td>${ft ? ft.toLocaleTimeString('es-ES',{hour:'2-digit',minute:'2-digit'}) : '—'}</td><td class="text-muted text-sm">${t.notas||''}</td></tr>`;
    }).join('');
}

// =============================================
// USUARIOS
// =============================================
async function cargarUsuarios() {
    const result = await api('auth.php?accion=listar_usuarios');
    const lista  = result.usuarios || [];
    const tbody  = document.getElementById('tabla-usuarios');
    tbody.innerHTML = lista.map(u => `<tr>
        <td><strong>${u.nombre} ${u.apellidos}</strong></td>
        <td>${u.email}</td>
        <td><span class="badge badge-${u.rol}">${ucfirst(u.rol)}</span></td>
        <td><span class="badge" style="background:${u.activo?'#C6F6D5':'#FED7D7'};color:${u.activo?'#22543D':'#742A2A'}">${u.activo?'Activo':'Inactivo'}</span></td>
        <td class="text-muted text-sm">${u.ultimo_acceso ? new Date(u.ultimo_acceso).toLocaleString('es-ES') : 'Nunca'}</td>
        <td>${usuarioActual.rol==='admin' ? `<button class="btn btn-sm btn-secondary" onclick="toggleUsuario(${u.id},${u.activo?0:1})">${u.activo?'🚫 Desactivar':'✅ Activar'}</button>` : ''}</td>
    </tr>`).join('');
}

async function abrirModalUsuario() {
    ['usr-nombre','usr-apellidos','usr-email','usr-password'].forEach(id => document.getElementById(id).value = '');
    document.getElementById('modal-usr-alerta').classList.add('hidden');
    document.getElementById('modal-usuario').classList.remove('hidden');
}

async function guardarUsuario() {
    const alerta = document.getElementById('modal-usr-alerta');
    alerta.classList.add('hidden');
    const data = {
        nombre:    document.getElementById('usr-nombre').value.trim(),
        apellidos: document.getElementById('usr-apellidos').value.trim(),
        email:     document.getElementById('usr-email').value.trim(),
        password:  document.getElementById('usr-password').value,
        rol:       document.getElementById('usr-rol').value,
    };
    if (!data.nombre || !data.email || !data.password) {
        alerta.textContent = '⚠️ Rellena los campos obligatorios.';
        alerta.classList.remove('hidden'); return;
    }
    const res = await api('auth.php?accion=registro', 'POST', data);
    if (res.ok) {
        cerrarModal('modal-usuario');
        cargarUsuarios();
        if (data.rol === 'paciente') cargarSelectorPacienteGlobal();
    } else {
        alerta.textContent = '⚠️ ' + (res.error || 'Error al crear');
        alerta.classList.remove('hidden');
    }
}

async function toggleUsuario(id, activo) {
    await api('auth.php?accion=editar_usuario', 'POST', { id, activo });
    cargarUsuarios();
}

// =============================================
// ESTADÍSTICAS
// =============================================
async function cargarEstadisticas() {
    if (!pacienteSeleccionado) return;
    const desde  = document.getElementById('inf-desde').value;
    const hasta  = document.getElementById('inf-hasta').value;
    const result = await api(`informes.php?accion=estadisticas&paciente=${pacienteSeleccionado}&desde=${desde}&hasta=${hasta}`);
    const s = result.resumen || {};
    document.getElementById('stats-informes').innerHTML = `
        <div class="stat-card"><div class="stat-icon" style="background:#EBF8FF;"><img src="img/iconos/chart.png" style="width:28px;height:28px;object-fit:contain;"></div><div><div class="num" style="color:#3182CE;">${s.total||0}</div><div class="label">Tomas programadas</div></div></div>
        <div class="stat-card"><div class="stat-icon" style="background:#F0FFF4;"><img src="img/iconos/check_color.png" style="width:28px;height:28px;object-fit:contain;"></div><div><div class="num" style="color:#38A169;">${s.tomadas||0}</div><div class="label">Tomadas</div></div></div>
        <div class="stat-card"><div class="stat-icon" style="background:#FFF5F5;"><img src="img/iconos/warning.png" style="width:28px;height:28px;object-fit:contain;"></div><div><div class="num" style="color:#E53E3E;">${s.olvidadas||0}</div><div class="label">Olvidadas</div></div></div>
        <div class="stat-card"><div class="stat-icon" style="background:#E9D8FD;"><img src="img/iconos/chart.png" style="width:28px;height:28px;object-fit:contain;"></div><div><div class="num" style="color:#2E86AB;">${s.adherencia||0}%</div><div class="label">Adherencia</div></div></div>
    `;
    const porMed = result.por_medicamento || [];
    document.getElementById('stats-meds-list').innerHTML = porMed.map(m => `
        <div style="margin-bottom:16px;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
                <div style="display:flex;align-items:center;gap:8px;"><div style="width:10px;height:10px;border-radius:50%;background:${m.color};"></div><strong>${m.nombre}</strong></div>
                <span style="font-size:13px;color:#718096;">${m.tomadas}/${m.total} tomas · ${m.adherencia}%</span>
            </div>
            <div class="progress-bar"><div class="progress-fill" style="width:${m.adherencia}%;background:${m.color};"></div></div>
        </div>`).join('') || '<p class="text-muted text-sm">Sin datos para mostrar</p>';
}

function abrirInformePDF() {
    const desde = document.getElementById('inf-desde')?.value || new Date().toISOString().split('T')[0].substring(0,7)+'-01';
    const hasta = document.getElementById('inf-hasta')?.value || new Date().toISOString().split('T')[0];
    window.open(`php/informes.php?accion=pdf&paciente=${pacienteSeleccionado}&desde=${desde}&hasta=${hasta}`, '_blank');
}

// =============================================
// UTILIDADES
// =============================================
function cerrarModal(id) { document.getElementById(id).classList.add('hidden'); }
function ucfirst(str) { return str ? str.charAt(0).toUpperCase() + str.slice(1) : ''; }
document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.classList.add('hidden'); });
});