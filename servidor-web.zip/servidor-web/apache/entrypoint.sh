#!/bin/bash

# Configurar directorio SSH para www-data
mkdir -p /var/www/.ssh
cp /home/proyecto/.ssh/mysql_backup_key /var/www/.ssh/mysql_backup_key
chown -R www-data:www-data /var/www/.ssh
chmod 700 /var/www/.ssh
chmod 600 /var/www/.ssh/mysql_backup_key

# Añadir servidor remoto a known_hosts de www-data
ssh-keyscan -H 192.168.2.4 >> /var/www/.ssh/known_hosts 2>/dev/null
chown www-data:www-data /var/www/.ssh/known_hosts
chmod 600 /var/www/.ssh/known_hosts

# Configurar directorio GNUPG para www-data
mkdir -p /var/www/backups/.gnupg
chown -R www-data:www-data /var/www/backups/.gnupg
chmod 700 /var/www/backups/.gnupg

# Configurar permisos del log
touch /var/www/backups/mysql_backup.log
chown www-data:www-data /var/www/backups/mysql_backup.log
chmod 664 /var/www/backups/mysql_backup.log

# Arrancar Apache
exec apache2-foreground
