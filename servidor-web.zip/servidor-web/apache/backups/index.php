<?php
$directorio       = '/var/www/backups/mysql';
$directorioRemoto = 'backupuser@192.168.2.4:/home/backupuser/mysql_backups';
$mensaje          = '';
$mensajeCron      = '';

if (!is_dir($directorio)) mkdir($directorio, 0755, true);

require 'acciones.php';
require 'cron.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Backups — CareMind</title>
    <link rel="icon" href="img/iconos/BBDD.png" type="image/png">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="topbar">
    <img src="img/iconos/BBDD2.png" alt="" class="logo">
    <div>
        <h1>Care<span>Mind</span> Backups</h1>
        <p>Gestión de copias de seguridad — caremind_db</p>
    </div>
</div>

<div class="layout">
    <div class="col-izquierda">
        <div class="card">
            <?php require 'archivos.php'; ?>
        </div>
    </div>
    <div class="col-derecha">
        <?php require 'vistas/backup_manual.php'; ?>
        <?php require 'vistas/cron_form.php'; ?>
    </div>
</div>

</body>
</html>
