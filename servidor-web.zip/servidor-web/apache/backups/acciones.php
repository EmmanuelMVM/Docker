<?php
// GNUPGHOME accesible por www-data
$gnupgHome = '/var/www/backups/.gnupg';
if (!is_dir($gnupgHome)) {
    mkdir($gnupgHome, 0700, true);
}
$gpgCmd = "GNUPGHOME=" . escapeshellarg($gnupgHome) . " gpg --batch --yes --no-tty --passphrase 'asix'";

// CREAR BACKUP MANUAL
if (isset($_GET['crear_backup'])) {
    $output  = shell_exec("bash /var/www/backups/copiar_backup.sh 2>&1");
    $mensaje = "<p>✅ Copia de seguridad iniciada." . ($output ? " Salida: " . htmlspecialchars($output) : "") . "</p>";
}

// ELIMINAR TODOS LOS ARCHIVOS
if (isset($_GET['eliminar_todo'])) {
    $archivosEliminar = scandir($directorio);
    $eliminados = 0; $errores = 0;
    foreach ($archivosEliminar as $arch) {
        if ($arch === '.' || $arch === '..') continue;
        $ruta = $directorio . '/' . $arch;
        if (is_file($ruta)) {
            unlink($ruta) ? $eliminados++ : $errores++;
        }
    }
    $mensaje = "<p>Se eliminaron $eliminados archivo(s)." . ($errores ? " $errores no pudieron eliminarse." : "") . "</p>";
}

// VER SQL
if (isset($_GET['ver'])) {
    $archivo = $_GET['ver'];
    if (file_exists($directorio . '/' . $archivo) && pathinfo($archivo, PATHINFO_EXTENSION) === 'sql') {
        shell_exec("gedit " . escapeshellarg($directorio . '/' . $archivo) . " > /dev/null 2>&1 &");
    } else {
        $mensaje = "<p>Archivo no válido o no encontrado.</p>";
    }
}

// BLOQUEAR SQL -> GZ -> GPG
if (isset($_GET['bloquear'])) {
    $archivo = $_GET['bloquear'];
    $ext     = pathinfo($archivo, PATHINFO_EXTENSION);
    $rutaOriginal = $directorio . '/' . $archivo;

    if (file_exists($rutaOriginal) && ($ext === 'sql' || $ext === 'gz')) {

        if ($ext === 'sql') {
            shell_exec("gzip -f " . escapeshellarg($rutaOriginal) . " 2>&1");
            $gzFile = $rutaOriginal . '.gz';
        } else {
            $gzFile = $rutaOriginal;
        }

        if (file_exists($gzFile)) {
            $cmdGpg = "$gpgCmd --symmetric --cipher-algo AES256 " . escapeshellarg($gzFile) . " 2>&1";
            $outGpg = shell_exec($cmdGpg);
            $gpgFile = $gzFile . '.gpg';

            if (file_exists($gpgFile)) {
                unlink($gzFile);
                $mensaje = "<p>✅ El archivo $archivo ha sido bloqueado correctamente.</p>";
            } else {
                $mensaje = "<p>❌ Error GPG: <pre>" . htmlspecialchars($outGpg) . "</pre>Cmd: <pre>" . htmlspecialchars($cmdGpg) . "</pre></p>";
            }
        } else {
            $mensaje = "<p>❌ Error: la compresión gzip falló. El archivo original se conserva.</p>";
        }
    } else {
        $mensaje = "<p>❌ Archivo no válido o no encontrado.</p>";
    }
}

// DESBLOQUEAR GPG -> GZ -> SQL
if (isset($_GET['desbloquear'])) {
    $archivo = $_GET['desbloquear'];
    $gpgFile = $directorio . '/' . $archivo;

    if (file_exists($gpgFile) && pathinfo($archivo, PATHINFO_EXTENSION) === 'gpg') {
        $gzFile = preg_replace('/\.gpg$/', '', $gpgFile);
        shell_exec("$gpgCmd --output " . escapeshellarg($gzFile) . " --decrypt " . escapeshellarg($gpgFile) . " 2>&1");

        if (file_exists($gzFile)) {
            shell_exec("gunzip -f " . escapeshellarg($gzFile) . " 2>&1");
            $sqlFile = preg_replace('/\.gz$/', '', $gzFile);

            if (file_exists($sqlFile)) {
                unlink($gpgFile);
                $mensaje = "<p>✅ El archivo $archivo ha sido desbloqueado correctamente.</p>";
            } else {
                $mensaje = "<p>❌ Error: la descompresión gzip falló. El archivo .gz se conserva.</p>";
            }
        } else {
            $mensaje = "<p>❌ Error: el descifrado GPG falló. El archivo original se conserva.</p>";
        }
    } else {
        $mensaje = "<p>❌ Archivo no válido o no encontrado.</p>";
    }
}

// ELIMINAR UN ARCHIVO
if (isset($_GET['eliminar'])) {
    $archivoEliminar = $_GET['eliminar'];
    if (file_exists($directorio . '/' . $archivoEliminar)) {
        $mensaje = unlink($directorio . '/' . $archivoEliminar)
            ? "<p>El archivo $archivoEliminar ha sido eliminado correctamente.</p>"
            : "<p>No se pudo eliminar el archivo $archivoEliminar.</p>";
    } else {
        $mensaje = "<p>El archivo $archivoEliminar no existe.</p>";
    }
}

// LIMPIAR LOG
if (isset($_GET['limpiar_log'])) {
    $logFile = '/var/www/backups/mysql_backup.log';
    file_put_contents($logFile, '');
    $mensaje = "<p>🧹 Log limpiado correctamente.</p>";
}

// ELIMINAR TODOS LOS ARCHIVOS
if (isset($_GET['eliminar_todo'])) {
    $archivosEliminar = scandir($directorio);
    $eliminados = 0; $errores = 0;
    foreach ($archivosEliminar as $arch) {
        if ($arch === '.' || $arch === '..') continue;
        $ruta = $directorio . '/' . $arch;
        if (is_file($ruta)) {
            unlink($ruta) ? $eliminados++ : $errores++;
        }
    }
    $mensaje = "<p>Se eliminaron $eliminados archivo(s)." . ($errores ? " $errores no pudieron eliminarse." : "") . "</p>";
}

// VER SQL
if (isset($_GET['ver'])) {
    $archivo = $_GET['ver'];
    if (file_exists($directorio . '/' . $archivo) && pathinfo($archivo, PATHINFO_EXTENSION) === 'sql') {
        shell_exec("gedit " . escapeshellarg($directorio . '/' . $archivo) . " > /dev/null 2>&1 &");
    } else {
        $mensaje = "<p>Archivo no válido o no encontrado.</p>";
    }
}

// BLOQUEAR SQL -> GZ -> GPG
if (isset($_GET['bloquear'])) {
    $archivo = $_GET['bloquear'];
    $ext     = pathinfo($archivo, PATHINFO_EXTENSION);
    $rutaOriginal = $directorio . '/' . $archivo;

    if (file_exists($rutaOriginal) && ($ext === 'sql' || $ext === 'gz')) {

        // Si es .sql, primero comprimir
        if ($ext === 'sql') {
            shell_exec("gzip -f " . escapeshellarg($rutaOriginal) . " 2>&1");
            $gzFile = $rutaOriginal . '.gz';
        } else {
            // Ya es .gz, usar directamente
            $gzFile = $rutaOriginal;
        }

        if (file_exists($gzFile)) {
            shell_exec("gpg --batch --yes --passphrase 'asix' --symmetric --cipher-algo AES256 " . escapeshellarg($gzFile) . " 2>&1");
            $gpgFile = $gzFile . '.gpg';

            if (file_exists($gpgFile)) {
                unlink($gzFile);
                $mensaje = "<p>✅ El archivo $archivo ha sido bloqueado correctamente.</p>";
            } else {
                $mensaje = "<p>❌ Error GPG: <pre>" . htmlspecialchars($outGpg) . "</pre>Cmd: <pre>" . htmlspecialchars($cmdGpg) . "</pre></p>";
            }
        } else {
            $mensaje = "<p>❌ Error: la compresión gzip falló. El archivo original se conserva.</p>";
        }
    } else {
        $mensaje = "<p>❌ Archivo no válido o no encontrado.</p>";
    }
}

// DESBLOQUEAR GPG -> GZ -> SQL
if (isset($_GET['desbloquear'])) {
    $archivo = $_GET['desbloquear'];
    $gpgFile = $directorio . '/' . $archivo;

    if (file_exists($gpgFile) && pathinfo($archivo, PATHINFO_EXTENSION) === 'gpg') {
        $gzFile = preg_replace('/\.gpg$/', '', $gpgFile);
        shell_exec("gpg --batch --yes --passphrase 'asix' --output " . escapeshellarg($gzFile) . " --decrypt " . escapeshellarg($gpgFile) . " 2>&1");

        if (file_exists($gzFile)) {
            shell_exec("gunzip -f " . escapeshellarg($gzFile) . " 2>&1");
            $sqlFile = preg_replace('/\.gz$/', '', $gzFile);

            if (file_exists($sqlFile)) {
                unlink($gpgFile);
                $mensaje = "<p>✅ El archivo $archivo ha sido desbloqueado correctamente.</p>";
            } else {
                $mensaje = "<p>❌ Error: la descompresión gzip falló. El archivo .gz se conserva.</p>";
            }
        } else {
            $mensaje = "<p>❌ Error: el descifrado GPG falló. El archivo original se conserva.</p>";
        }
    } else {
        $mensaje = "<p>❌ Archivo no válido o no encontrado.</p>";
    }
}

// ELIMINAR UN ARCHIVO
if (isset($_GET['eliminar'])) {
    $archivoEliminar = $_GET['eliminar'];
    if (file_exists($directorio . '/' . $archivoEliminar)) {
        $mensaje = unlink($directorio . '/' . $archivoEliminar)
            ? "<p>El archivo $archivoEliminar ha sido eliminado correctamente.</p>"
            : "<p>No se pudo eliminar el archivo $archivoEliminar.</p>";
    } else {
        $mensaje = "<p>El archivo $archivoEliminar no existe.</p>";
    }
}

// LIMPIAR LOG
if (isset($_GET['limpiar_log'])) {
    $logFile = '/home/proyecto/backups/mysql_backup.log';
    file_put_contents($logFile, '');
    $mensaje = "<p>🧹 Log limpiado correctamente.</p>";
}