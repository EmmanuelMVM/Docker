<?php
if (!is_dir($directorio)) mkdir($directorio, 0755, true);

$archivos = scandir($directorio);
$archivos = array_filter($archivos, fn($a) => $a !== '.' && $a !== '..');

if (isset($_GET['buscar'])) {
    $buscar   = strtolower($_GET['buscar']);
    $archivos = array_filter($archivos, fn($a) => strpos(strtolower($a), $buscar) !== false);
}

usort($archivos, function($a, $b) {
    preg_match('/(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})/', $a, $matchA);
    preg_match('/(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})/', $b, $matchB);
    $fechaA = $matchA[1] ?? '0000-00-00_00-00-00';
    $fechaB = $matchB[1] ?? '0000-00-00_00-00-00';
    if ($fechaA !== $fechaB) return strcmp($fechaB, $fechaA);
    $orden = ['sql' => 1, 'gz' => 2, 'gpg' => 3];
    $pA = $orden[pathinfo($a, PATHINFO_EXTENSION)] ?? 4;
    $pB = $orden[pathinfo($b, PATHINFO_EXTENSION)] ?? 4;
    return $pA - $pB;
});
?>

<div class="card-title">
    <img src="img/iconos/archive.png" alt=""> Archivos de Backup — caremind_db
</div>

<form method="GET" class="search-bar">
    <input type="text" name="buscar" placeholder="🔍 Buscar archivo..."
           value="<?= isset($_GET['buscar']) ? htmlspecialchars($_GET['buscar']) : '' ?>">
    <button type="submit" class="btn btn-neutral">Buscar</button>
    <button type="submit" name="eliminar_todo" value="1" class="btn btn-danger"
            onclick="return confirm('¿Seguro que deseas eliminar TODOS los archivos?')">
        <img src="img/iconos/bin.png" alt=""> Eliminar todo
    </button>
</form>

<?php if (empty($archivos)): ?>
    <div class="empty">
        <img src="img/iconos/archive.png" alt="">
        No hay archivos de backup todavía.<br>Crea uno desde el panel de la derecha.
    </div>
<?php else: ?>
<ul class="file-list">
<?php foreach ($archivos as $archivo):
    $ext   = pathinfo($archivo, PATHINFO_EXTENSION);
    $ruta  = $directorio . '/' . $archivo;
    $esDir = is_dir($ruta);

    if ($esDir)           $icono = 'archive.png';
    elseif ($ext === 'sql') $icono = 'BBDD.png';
    elseif ($ext === 'gz')  $icono = 'archive.png';
    elseif ($ext === 'gpg') $icono = 'padlock_close.png';
    else                    $icono = 'warning.png';

    $tamano = '';
    if (is_file($ruta)) {
        $bytes  = filesize($ruta);
        $tamano = $bytes < 1024 ? "{$bytes}B" : ($bytes < 1048576 ? round($bytes/1024,1)."KB" : round($bytes/1048576,2)."MB");
    }
?>
    <li class="file-item">
        <img src="img/iconos/<?= $icono ?>" class="file-icon" alt="">
        <span class="file-name"><?= htmlspecialchars($archivo) ?></span>
        <?php if ($tamano): ?><span class="file-size"><?= $tamano ?></span><?php endif; ?>
        <span class="file-actions">
            <?php if ($ext === 'sql'): ?>
                <a href="?bloquear=<?= urlencode($archivo) ?>">
                    <button class="btn btn-lock"><img src="img/iconos/padlock_close.png" alt=""> Bloquear</button>
                </a>
            <?php endif; ?>
            <?php if ($ext === 'gpg'): ?>
                <a href="?desbloquear=<?= urlencode($archivo) ?>">
                    <button class="btn btn-unlock"><img src="img/iconos/padlock_open.png" alt=""> Desbloquear</button>
                </a>
            <?php endif; ?>
            <a href="?eliminar=<?= urlencode($archivo) ?>" onclick="return confirm('¿Seguro?')">
                <button class="btn btn-danger"><img src="img/iconos/bin.png" alt=""></button>
            </a>
        </span>
    </li>
<?php endforeach; ?>
</ul>
<?php endif; ?>

<?php if ($mensaje) echo $mensaje; ?>
