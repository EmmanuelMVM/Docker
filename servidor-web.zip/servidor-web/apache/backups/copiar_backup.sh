#!/bin/bash
# ==========================
# CONFIGURACIÓN
# ==========================
CONTAINER_NAME="mysql_db"
DB_USER="usuario"
DB_PASSWORD="asix"
DB_NAME="caremind_db"
BACKUP_DIR="/var/www/backups/mysql"
LOG_FILE="/var/www/backups/mysql_backup.log"
REMOTE_USER="backupuser"
REMOTE_HOST="192.168.2.4"
REMOTE_DIR="/home/backupuser/mysql_backups"
SSH_KEY="/var/www/.ssh/mysql_backup_key"
GPG_PASSWORD="asix"
MAIL_TO="usuario@caremind.test"
DATE=$(date +"%Y-%m-%d_%H-%M-%S")
BACKUP_FILE="backup_${DB_NAME}_${DATE}.sql"
RETENTION_DAYS=7

# ==========================
# FUNCIÓN ENVÍO EMAIL
# ==========================
send_mail() {
    SUBJECT="$1"
    BODY="$2"
    echo -e "Subject: $SUBJECT\n\n$BODY" | msmtp "$MAIL_TO" 2>/dev/null || true
}

# ==========================
# CREACIÓN DE DIRECTORIOS
# ==========================
mkdir -p "$BACKUP_DIR"
echo "[$(date)] Iniciando copia de seguridad..." >> "$LOG_FILE"

# ==========================
# DUMP MYSQL
# ==========================
docker exec -i $CONTAINER_NAME mysqldump -u $DB_USER -p$DB_PASSWORD $DB_NAME > "$BACKUP_DIR/$BACKUP_FILE"
if [ $? -ne 0 ]; then
    MSG="[$(date)] ERROR en mysqldump para la base de datos $DB_NAME"
    echo "$MSG" >> "$LOG_FILE"
    send_mail "❌ ERROR Backup MySQL - CareMind" "$MSG"
    exit 1
fi
echo "[$(date)] Dump completado: $BACKUP_FILE" >> "$LOG_FILE"

# ==========================
# COMPRESIÓN
# ==========================
gzip "$BACKUP_DIR/$BACKUP_FILE"
echo "[$(date)] Comprimido: $BACKUP_FILE.gz" >> "$LOG_FILE"

# ==========================
# CIFRADO GPG
# ==========================
GNUPGHOME=/var/www/backups/.gnupg gpg --batch --yes --passphrase "$GPG_PASSWORD" \
    --symmetric --cipher-algo AES256 \
    "$BACKUP_DIR/$BACKUP_FILE.gz"
if [ $? -ne 0 ]; then
    MSG="[$(date)] ERROR en cifrado GPG del backup $BACKUP_FILE"
    echo "$MSG" >> "$LOG_FILE"
    send_mail "❌ ERROR Backup GPG - CareMind" "$MSG"
    exit 1
fi
rm "$BACKUP_DIR/$BACKUP_FILE.gz"
echo "[$(date)] Cifrado: $BACKUP_FILE.gz.gpg" >> "$LOG_FILE"

# ==========================
# ENVÍO REMOTO (opcional)
# ==========================
if [ -f "$SSH_KEY" ]; then
    scp -i $SSH_KEY "$BACKUP_DIR/$BACKUP_FILE.gz.gpg" ${REMOTE_USER}@${REMOTE_HOST}:${REMOTE_DIR}
    if [ $? -ne 0 ]; then
        MSG="[$(date)] AVISO: No se pudo enviar al servidor remoto ($REMOTE_HOST). Backup local guardado."
        echo "$MSG" >> "$LOG_FILE"
        send_mail "⚠️ Backup guardado pero no enviado remotamente - CareMind" "$MSG"
    else
        echo "[$(date)] Enviado al remoto: $REMOTE_HOST" >> "$LOG_FILE"
    fi
else
    echo "[$(date)] AVISO: Sin clave SSH. Backup solo local." >> "$LOG_FILE"
fi

# ==========================
# LIMPIEZA (backups > 7 días)
# ==========================
find "$BACKUP_DIR" -type f -mtime +$RETENTION_DAYS \( -name "*.gpg" -o -name "*.sql" -o -name "*.gz" \) -delete
echo "[$(date)] Limpieza completada." >> "$LOG_FILE"

# ==========================
# ÉXITO FINAL
# ==========================
MSG="[$(date)] ✅ Backup completado correctamente
Base de datos: $DB_NAME
Archivo: $BACKUP_FILE.gz.gpg
Directorio: $BACKUP_DIR"
echo "$MSG" >> "$LOG_FILE"
echo "--------------------------------------" >> "$LOG_FILE"
send_mail "✅ Backup completado - CareMind" "$MSG"
exit 0
