<?php
// PROGRAMAR CRON
if (isset($_POST['programar_cron'])) {
    $minuto = max(0, min(59, intval($_POST['minuto'] ?? 0)));
    $hora   = max(0, min(23, intval($_POST['hora']   ?? 0)));
    $diaMes = preg_match('/^(\*|[1-9]|[12]\d|3[01])$/', $_POST['dia_mes'] ?? '') ? trim($_POST['dia_mes']) : '*';
    $mes    = preg_match('/^(\*|[1-9]|1[0-2])$/',       $_POST['mes']     ?? '') ? trim($_POST['mes'])     : '*';
    $diaSem = preg_match('/^(\*|[0-6])$/',               $_POST['dia_sem'] ?? '') ? trim($_POST['dia_sem']) : '*';

    $rutaScript = realpath('copiar_backup.sh');
    $nuevaLinea = "$minuto $hora $diaMes $mes $diaSem bash $rutaScript";

    $crontabActual = shell_exec("crontab -l 2>/dev/null") ?? '';
    $lineas = array_filter(explode("\n", $crontabActual), function($l) use ($rutaScript) {
        return strpos($l, $rutaScript) === false && strpos($l, 'copiar_backup.sh') === false;
    });
    $lineas[] = $nuevaLinea;

    $tmpFile = tempnam(sys_get_temp_dir(), 'cron_');
    file_put_contents($tmpFile, implode("\n", $lineas) . "\n");
    shell_exec("crontab $tmpFile");
    unlink($tmpFile);

    $mensajeCron = "<p>✅ Cron programado: <code>$nuevaLinea</code></p>";
}

// ELIMINAR CRON
if (isset($_GET['eliminar_cron'])) {
    $crontabActual = shell_exec("crontab -l 2>/dev/null") ?? '';
    $lineas = array_filter(explode("\n", $crontabActual), function($l) {
        return strpos($l, 'copiar_backup.sh') === false;
    });
    $tmpFile = tempnam(sys_get_temp_dir(), 'cron_');
    file_put_contents($tmpFile, implode("\n", $lineas) . "\n");
    shell_exec("crontab $tmpFile");
    unlink($tmpFile);
    $mensajeCron = "<p>🗑️ Entrada del cron eliminada correctamente.</p>";
}

// LEER CRON ACTIVO
$cronActivo = '';
$crontabActual = shell_exec("crontab -l 2>/dev/null") ?? '';
foreach (explode("\n", $crontabActual) as $linea) {
    if (strpos($linea, 'copiar_backup.sh') !== false) {
        $cronActivo = trim($linea);
        break;
    }
}

// Valores para pre-rellenar el formulario
$valMinuto = 0; $valHora = 0; $valDiaMes = '*'; $valMes = '*'; $valDiaSem = '*';
if ($cronActivo) {
    $partes = preg_split('/\s+/', $cronActivo);
    if (count($partes) >= 5) {
        [$valMinuto, $valHora, $valDiaMes, $valMes, $valDiaSem] = $partes;
    }
}