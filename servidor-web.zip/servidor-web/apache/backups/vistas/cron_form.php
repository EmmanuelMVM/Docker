<div style="border:2px solid #2196F3; border-radius:8px; padding:16px; background:#f0f8ff;">
    <p style="margin:0 0 12px 0; font-size:16px; font-weight:bold;">🕐 Programar Copia Automática</p>

    <?php if ($cronActivo): ?>
        <p style="font-size:13px; color:#555;">
            ⚙️ Cron activo: <code style="background:#e8e8e8; padding:2px 6px; border-radius:4px;"><?= htmlspecialchars($cronActivo) ?></code>
            <a href="?eliminar_cron=1" onclick="return confirm('¿Eliminar la programación actual?')">
                <button style="background:#e53935; color:white; border:none; border-radius:4px; padding:3px 8px; cursor:pointer;">🗑️</button>
            </a>
        </p>
    <?php else: ?>
        <p style="font-size:13px; color:#999;">⚙️ Sin programación activa.</p>
    <?php endif; ?>

    <form method="POST" style="display:flex; flex-direction:column; gap:10px;">
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
            <?php foreach ([
                ['minuto',  'Minuto',   '0-59', 'number', 0,  59,  $valMinuto],
                ['hora',    'Hora',     '0-23', 'number', 0,  23,  $valHora],
                ['dia_mes', 'Día mes',  '1-31/*','text',  null,null,$valDiaMes],
                ['mes',     'Mes',      '1-12/*','text',  null,null,$valMes],
                ['dia_sem', 'Día sem',  '0-6/*', 'text',  null,null,$valDiaSem],
            ] as [$name, $label, $hint, $type, $min, $max, $val]): ?>
            <div style="display:flex; flex-direction:column; gap:3px;">
                <label style="font-size:12px; font-weight:bold;"><?= $label ?> <span style="color:#888;">(<?= $hint ?>)</span></label>
                <input type="<?= $type ?>" name="<?= $name ?>" value="<?= htmlspecialchars($val) ?>"
                       <?= $min !== null ? "min=$min max=$max" : '' ?>
                       style="width:58px; padding:5px; border:1px solid #ccc; border-radius:4px;">
            </div>
            <?php endforeach; ?>
        </div>
        <button type="submit" name="programar_cron"
                style="background:#2196F3; color:white; padding:10px; font-size:14px; border:none; border-radius:5px; cursor:pointer; width:100%;">
            📅 PROGRAMAR
        </button>
    </form>

    <p style="margin:8px 0 0 0; font-size:11px; color:#888;">
        Usa <strong>*</strong> para "cualquier valor". Ej: <code>0 3 * * 1</code> = lunes a las 3:00.
    </p>

    <?php if ($mensajeCron) echo $mensajeCron; ?>
</div>