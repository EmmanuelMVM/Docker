<div style="border:2px solid #4CAF50; border-radius:8px; padding:16px; background:#f9fff9;">
    <p style="margin:0 0 10px 0; font-size:16px; font-weight:bold;">🛡️ Crea una Copia de Seguridad Ahora</p>
    <a href="?crear_backup=1" onclick="return confirm('¿Deseas crear una copia de seguridad ahora?')">
        <button style="background:#4CAF50; color:white; padding:10px 20px; font-size:15px; border:none; border-radius:5px; cursor:pointer; width:100%;">
            CREAR AHORA
        </button>
    </a>
</div>