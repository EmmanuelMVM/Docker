CREATE DATABASE IF NOT EXISTS caremind_db;
USE caremind_db;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellidos VARCHAR(150) NOT NULL,
    email VARCHAR(200) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    rol ENUM('admin', 'cuidador', 'paciente') NOT NULL DEFAULT 'paciente',
    activo TINYINT(1) DEFAULT 1,
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
    ultimo_acceso DATETIME NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS cuidador_paciente (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_cuidador INT NOT NULL,
    id_paciente INT NOT NULL,
    fecha_asignacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_cuidador) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_paciente) REFERENCES usuarios(id) ON DELETE CASCADE,
    UNIQUE KEY unico_par (id_cuidador, id_paciente)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS medicamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_paciente INT NOT NULL,
    id_creado_por INT NOT NULL,
    nombre VARCHAR(200) NOT NULL,
    principio_activo VARCHAR(200) NULL,
    dosis VARCHAR(100) NOT NULL,
    unidad VARCHAR(50) NOT NULL DEFAULT 'mg',
    via_administracion ENUM('oral','sublingual','topica','inyectable','inhalada','nasal','rectal') DEFAULT 'oral',
    instrucciones TEXT NULL,
    color VARCHAR(7) DEFAULT '#2E86AB',
    activo TINYINT(1) DEFAULT 1,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NULL,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_paciente) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_creado_por) REFERENCES usuarios(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS horarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_medicamento INT NOT NULL,
    hora TIME NOT NULL,
    dias_semana VARCHAR(20) NOT NULL DEFAULT '1234567',
    FOREIGN KEY (id_medicamento) REFERENCES medicamentos(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tomas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_horario INT NOT NULL,
    id_medicamento INT NOT NULL,
    id_paciente INT NOT NULL,
    fecha_programada DATETIME NOT NULL,
    fecha_tomada DATETIME NULL,
    estado ENUM('pendiente','tomada','olvidada','pospuesta') DEFAULT 'pendiente',
    notas TEXT NULL,
    alerta_enviada TINYINT(1) DEFAULT 0,
    FOREIGN KEY (id_horario) REFERENCES horarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_medicamento) REFERENCES medicamentos(id) ON DELETE CASCADE,
    FOREIGN KEY (id_paciente) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS alertas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_toma INT NOT NULL,
    email_destino VARCHAR(200) NOT NULL,
    fecha_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
    enviado TINYINT(1) DEFAULT 0,
    error TEXT NULL,
    FOREIGN KEY (id_toma) REFERENCES tomas(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT IGNORE INTO usuarios (nombre, apellidos, email, password_hash, rol) VALUES
('Emmanuel', 'Admin',    'emmanuel@caremind.test', '$2b$12$xPoLHFTaHRgA0siw.3AAeegCuax.5tIXrBAgng.RS9FwOeBI1a69i', 'admin'),
('Lucas',    'Paciente', 'lucas@caremind.test',    '$2b$12$BUzpU0uF0bI1hYRT65.c4etrYCcBOyX/XJhJ3yDGK3riXMGCs5npG', 'paciente');

INSERT IGNORE INTO cuidador_paciente (id_cuidador, id_paciente) VALUES (1, 2);

GRANT ALL PRIVILEGES ON caremind_db.* TO 'usuario'@'%';
FLUSH PRIVILEGES;
